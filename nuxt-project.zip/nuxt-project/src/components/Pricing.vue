<template>
    <section id="pricing" class="pricing section light-background">
      <div class="container section-title" data-aos="fade-up">
        <h2>Pricing Plans</h2>
        <p>Choose a plan that fits your business needs</p>
      </div>
      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row g-4 justify-content-center">
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="pricing-card">
              <h3>Basic Plan</h3>
              <div class="price">
                <span class="currency">₹</span>
                <span class="amount">500</span>
                <span class="period">/ month</span>
              </div>
              <ul class="features-list">
                <li><i class="bi bi-check-circle-fill"></i> Unlimited user access</li>
                <li><i class="bi bi-check-circle-fill"></i> Single Branch</li>
                <li><i class="bi bi-check-circle-fill"></i> Billing and invoicing</li>
                <li><i class="bi bi-check-circle-fill"></i> Accounting integration</li>
                <li><i class="bi bi-check-circle-fill"></i> Customer support (email & phone)</li>
                <li><i class="bi bi-check-circle-fill"></i> Online Software Only</li>
                <li><i class="bi bi-check-circle-fill"></i> 30 Days Free Trial</li>
              </ul>
              <a href="#" class="btn btn-primary">Buy Now</a>
            </div>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="pricing-card popular">
              <div class="popular-badge">Most Popular</div>
              <h3>Standard Plan</h3>
              <div class="price">
                <span class="currency">₹</span>
                <span class="amount">1000</span>
                <span class="period">/ month</span>
              </div>
              <ul class="features-list">
                <li><i class="bi bi-check-circle-fill"></i> Unlimited user access</li>
                <li><i class="bi bi-check-circle-fill"></i> Multi Branch</li>
                <li><i class="bi bi-check-circle-fill"></i> Advanced billing and inventory management</li>
                <li><i class="bi bi-check-circle-fill"></i> CRM and marketing automation features</li>
                <li><i class="bi bi-check-circle-fill"></i> HR management with attendance and payroll integration</li>
                <li><i class="bi bi-check-circle-fill"></i> Customer support (email & 24/7 phone support)</li>
                <li><i class="bi bi-check-circle-fill"></i> Online & offline integrated Software</li>
                <li><i class="bi bi-check-circle-fill"></i> Dedicated Dashboard for analytics, reports, and controls</li>
                <li><i class="bi bi-check-circle-fill"></i> 30 Days Free Trial</li>
              </ul>
              <a href="#" class="btn btn-light">Buy Now</a>
            </div>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="300">
            <div class="pricing-card">
              <h3>Enterprise Plan</h3>
              <div class="price">Custom Pricing</div>
              <ul class="features-list">
                <li><i class="bi bi-check-circle-fill"></i> Unlimited users</li>
                <li><i class="bi bi-check-circle-fill"></i> Full-featured retail and enterprise management</li>
                <li><i class="bi bi-check-circle-fill"></i> Custom API integrations</li>
                <li><i class="bi bi-check-circle-fill"></i> Fully customized end-to-end automation</li>
                <li><i class="bi bi-check-circle-fill"></i> Advanced analytics and reporting</li>
                <li><i class="bi bi-check-circle-fill"></i> Dedicated account manager & 24/7 support</li>
              </ul>
              <a href="#" class="btn btn-primary">Contact Us</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </template>
  
  <script setup>
  </script>
  
  <style scoped>
  .pricing .pricing-card {
    height: 100%;
    padding: 2rem;
    background: var(--surface-color);
    border-radius: 1rem;
    transition: all 0.3s ease;
    position: relative;
  }
  
  .pricing .pricing-card:hover {
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  }
  
  .pricing .pricing-card.popular {
    background: var(--accent-color);
    color: var(--contrast-color);
  }
  
  .pricing .pricing-card.popular h3,
  .pricing .pricing-card.popular h4 {
    color: var(--contrast-color);
  }
  
  .pricing .pricing-card.popular .price .currency,
  .pricing .pricing-card.popular .price .amount,
  .pricing .pricing-card.popular .price .period {
    color: var(--contrast-color);
  }
  
  .pricing .pricing-card.popular .features-list li {
    color: var(--contrast-color);
  }
  
  .pricing .pricing-card.popular .features-list li i {
    color: var(--contrast-color);
  }
  
  .pricing .pricing-card.popular .btn-light {
    background: var(--contrast-color);
    color: var(--accent-color);
  }
  
  .pricing .pricing-card.popular .btn-light:hover {
    background: color-mix(in srgb, var(--contrast-color), transparent 10%);
  }
  
  .pricing .pricing-card .popular-badge {
    position: absolute;
    top: -12px;
    left: 50%;
    transform: translateX(-50%);
    background: var(--contrast-color);
    color: var(--accent-color);
    padding: 0.5rem 1rem;
    border-radius: 2rem;
    font-size: 0.875rem;
    font-weight: 600;
    box-shadow: 0px -2px 10px rgba(0, 0, 0, 0.08);
  }
  
  .pricing .pricing-card h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
  }
  
  .pricing .pricing-card .price {
    margin-bottom: 1.5rem;
  }
  
  .pricing .pricing-card .price .currency {
    font-size: 1.5rem;
    font-weight: 600;
    vertical-align: top;
    line-height: 1;
  }
  
  .pricing .pricing-card .price .amount {
    font-size: 3.5rem;
    font-weight: 700;
    line-height: 1;
  }
  
  .pricing .pricing-card .price .period {
    font-size: 1rem;
    color: color-mix(in srgb, var(--default-color), transparent 40%);
  }
  
  .pricing .pricing-card .description {
    margin-bottom: 2rem;
    font-size: 0.975rem;
  }
  
  .pricing .pricing-card h4 {
    font-size: 1.125rem;
    margin-bottom: 1rem;
  }
  
  .pricing .pricing-card .features-list {
    list-style: none;
    padding: 0;
    margin: 0 0 2rem 0;
  }
  
  .pricing .pricing-card .features-list li {
    display: flex;
    align-items: center;
    margin-bottom: 1rem;
  }
  
  .pricing .pricing-card .features-list li i {
    color: var(--accent-color);
    margin-right: 0.75rem;
    font-size: 1.25rem;
  }
  
  .pricing .pricing-card .btn {
    width: 100%;
    padding: 0.75rem 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    font-weight: 500;
    border-radius: 50px;
  }
  
  .pricing .pricing-card .btn.btn-primary {
    background: var(--accent-color);
    border: none;
    color: var(--contrast-color);
  }
  
  .pricing .pricing-card .btn.btn-primary:hover {
    background: color-mix(in srgb, var(--accent-color), transparent 15%);
  }
  </style>