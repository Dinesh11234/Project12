export default defineNuxtConfig({
  srcDir: 'src/',
  
  css: [
    '~/assets/css/main.css',
    '~/assets/vendor/bootstrap/css/bootstrap.min.css',
    '~/assets/vendor/bootstrap-icons/bootstrap-icons.css',
    '~/assets/vendor/aos/aos.css',
    '~/assets/vendor/swiper/swiper-bundle.min.css'
  ],
  plugins: [
    '~/plugins/glightbox.client.js',
    '~/plugins/aos.client.js'
  ],
  app: {
    head: {
      title: 'RX Square',
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'description', content: '' },
        { name: 'keywords', content: '' }
      ],
      link: [
        { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
        { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossorigin: 'anonymous' },
        { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&family=Inter:wght@100;200;300;400;500;600;700;800;900&family=Nunito:wght@200;300;400;500;600;700;800;900&display=swap' }
      ],
      script: [
        {
          src: 'https://cdn.jsdelivr.net/npm/@srexi/purecounterjs/dist/purecounter_vanilla.js',
          defer: true
        }
      ]
    }
  },
  modules: ["@pinia/nuxt"],
  postcss: {
    plugins: {
      tailwindcss: {},
      autoprefixer: {},
    },
  },

  pinia: {
    storesDirs: ['./src/store/**'],
  },

  extensions: [
    ".js",
    ".jsx",
    ".mjs",
    ".ts",
    ".tsx",
    ".vue"
  ],
  spaLoadingTemplate: false,
  compatibilityDate: "2025-02-15",
})