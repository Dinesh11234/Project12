<template>
    <section id="features" class="features section">
      <div class="container section-title" data-aos="fade-up">
        <h2>Features</h2>
        <p>Experience next-level automation with RX Square's smart billing and retail solutions.</p>
      </div>
      <div class="container">
        <div class="d-flex justify-content-center">
          <ul class="nav nav-tabs" data-aos="fade-up" data-aos-delay="100">
          <li class="nav-item">
            <a
              class="nav-link"
              :class="{ active: activeTab === 'features-tab-1' }"
              @click="setActiveTab('features-tab-1')"
            >
              <h4>Smart Billing</h4>
            </a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              :class="{ active: activeTab === 'features-tab-2' }"
              @click="setActiveTab('features-tab-2')"
            >
              <h4>Inventory Management</h4>
            </a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link"
              :class="{ active: activeTab === 'features-tab-3' }"
              @click="setActiveTab('features-tab-3')"
            >
              <h4>Sales & Analytics</h4>
            </a>
          </li>
        </ul>
        </div>
      <div class="tab-content" data-aos="fade-up" data-aos-delay="200">
        <div
          class="tab-pane fade"
          :class="{ 'active show': activeTab === 'features-tab-1' }"
          id="features-tab-1"
        >
          <div class="row">
            <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center">
              <h3>Fast & Secure Billing</h3>
              <p class="fst-italic">
                Enhance customer experience with seamless, quick, and secure transactions powered by RX Square.
              </p>
              <ul>
                <li><i class="bi bi-check2-all"></i> <span>Multi-payment support (Cash, UPI, Card, Wallets)</span></li>
                <li><i class="bi bi-check2-all"></i> <span>GST-compliant invoices with automated calculations</span></li>
                <li><i class="bi bi-check2-all"></i> <span>Discounts, coupons, and loyalty points integration</span></li>
              </ul>
            </div>
            <div class="col-lg-6 order-1 order-lg-2 text-center">
              <img src="assets/img/features-illustration-1.webp" alt="" class="img-fluid">
            </div>
          </div>
        </div>
        <div
          class="tab-pane fade"
          :class="{ 'active show': activeTab === 'features-tab-2' }"
          id="features-tab-2"
        >
          <div class="row">
            <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center">
              <h3>Real-time Inventory Control</h3>
              <p class="fst-italic">
                Keep track of stock levels and automate reordering to ensure seamless operations.
              </p>
              <ul>
                <li><i class="bi bi-check2-all"></i> <span>Auto stock updates on every sale</span></li>
                <li><i class="bi bi-check2-all"></i> <span>Low-stock alerts & auto-replenishment</span></li>
                <li><i class="bi bi-check2-all"></i> <span>Barcode & QR code scanning for easy stock management</span></li>
                <li><i class="bi bi-check2-all"></i> <span>Centralized inventory for multi-store management</span></li>
              </ul>
            </div>
            <div class="col-lg-6 order-1 order-lg-2 text-center">
              <img src="assets/img/features-illustration-2.webp" alt="" class="img-fluid">
            </div>
          </div>
        </div>
        <div
          class="tab-pane fade"
          :class="{ 'active show': activeTab === 'features-tab-3' }"
          id="features-tab-3"
        >
          <div class="row">
            <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0 d-flex flex-column justify-content-center">
              <h3>Data-Driven Sales Insights</h3>
              <ul>
                <li><i class="bi bi-check2-all"></i> <span>AI-powered sales forecasting</span></li>
                <li><i class="bi bi-check2-all"></i> <span>Daily, weekly, and monthly revenue reports</span></li>
                <li><i class="bi bi-check2-all"></i> <span>Customer purchase behavior analysis</span></li>
              </ul>
              <p class="fst-italic">
                Optimize your business strategy with real-time analytics and in-depth reports.
              </p>
            </div>
            <div class="col-lg-6 order-1 order-lg-2 text-center">
              <img src="assets/img/features-illustration-3.webp" alt="" class="img-fluid">
            </div>
          </div>
        </div>
      </div>
      </div>
    </section>
    <section id="features-cards" class="features-cards section">

      <div class="container">

        <div class="row gy-4">

          <div class="col-xl-3 col-md-6" data-aos="zoom-in" data-aos-delay="100">
            <div class="feature-box orange">
              <i class="bi bi-cash-coin"></i>
              <h4>Seamless Billing</h4>
              <p>Process transactions quickly with multi-payment support, automated invoices, and tax calculations.</p>
            </div>
          </div><!-- End Feature Box -->

          <div class="col-xl-3 col-md-6" data-aos="zoom-in" data-aos-delay="200">
            <div class="feature-box blue">
              <i class="bi bi-box-seam"></i>
              <h4>Smart Inventory</h4>
              <p>Track stock in real-time, receive low-stock alerts, and manage inventory across multiple locations.</p>
            </div>
          </div><!-- End Feature Box -->

          <div class="col-xl-3 col-md-6" data-aos="zoom-in" data-aos-delay="300">
            <div class="feature-box green">
              <i class="bi bi-graph-up"></i>
              <h4>Sales Insights</h4>
              <p>Analyze sales trends, generate performance reports, and make data-driven business decisions.</p>
            </div>
          </div><!-- End Feature Box -->

          <div class="col-xl-3 col-md-6" data-aos="zoom-in" data-aos-delay="400">
            <div class="feature-box red">
              <i class="bi bi-lock"></i>
              <h4>Secure & Scalable</h4>
              <p>Ensure data security with encrypted transactions and cloud backup for business scalability.</p>
            </div>
          </div><!-- End Feature Box -->

        </div>

      </div>

    </section>
    <section id="features-2" class="features-2 section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row align-items-center">

          <div class="col-lg-4">

            <div class="feature-item text-end mb-5" data-aos="fade-right" data-aos-delay="200">
              <div class="d-flex align-items-center justify-content-end gap-4">
                <div class="feature-content">
                  <h3>Seamless Billing</h3>
                  <p>Automate invoicing, generate GST-compliant bills, and process transactions swiftly with RX Square.</p>
                </div>
                <div class="feature-icon flex-shrink-0">
                  <i class="bi bi-receipt"></i>
                </div>
              </div>
            </div><!-- End .feature-item -->

            <div class="feature-item text-end mb-5" data-aos="fade-right" data-aos-delay="300">
              <div class="d-flex align-items-center justify-content-end gap-4">
                <div class="feature-content">
                  <h3>Smart Inventory</h3>
                  <p>Keep track of stock levels, set reorder alerts, and manage products efficiently with real-time updates.</p>
                </div>
                <div class="feature-icon flex-shrink-0">
                  <i class="bi bi-box"></i>
                </div>
              </div>
            </div><!-- End .feature-item -->

            <div class="feature-item text-end" data-aos="fade-right" data-aos-delay="400">
              <div class="d-flex align-items-center justify-content-end gap-4">
                <div class="feature-content">
                  <h3>Sales Insights</h3>
                  <p>Analyze performance trends, generate reports, and optimize revenue streams with data-driven insights.</p>
                </div>
                <div class="feature-icon flex-shrink-0">
                  <i class="bi bi-graph-up"></i>
                </div>
              </div>
            </div><!-- End .feature-item -->

          </div>

          <div class="col-lg-4" data-aos="zoom-in" data-aos-delay="200">
            <div class="phone-mockup text-center">
              <img src="assets/img/2.png" alt="RX Square Dashboard" class="img-fluid">
            </div>
          </div><!-- End Phone Mockup -->

          <div class="col-lg-4">

            <div class="feature-item mb-5" data-aos="fade-left" data-aos-delay="200">
              <div class="d-flex align-items-center gap-4">
                <div class="feature-icon flex-shrink-0">
                  <i class="bi bi-phone"></i>
                </div>
                <div class="feature-content">
                  <h3>Multi-Device Support</h3>
                  <p>Access RX Square on mobile, tablet, and desktop for seamless business management anywhere.</p>
                </div>
              </div>
            </div><!-- End .feature-item -->

            <div class="feature-item mb-5" data-aos="fade-left" data-aos-delay="300">
              <div class="d-flex align-items-center gap-4">
                <div class="feature-icon flex-shrink-0">
                  <i class="bi bi-lock"></i>
                </div>
                <div class="feature-content">
                  <h3>Secure Transactions</h3>
                  <p>Ensure safe and encrypted transactions with advanced security protocols and user authentication.</p>
                </div>
              </div>
            </div><!-- End .feature-item -->

            <div class="feature-item" data-aos="fade-left" data-aos-delay="400">
              <div class="d-flex align-items-center gap-4">
                <div class="feature-icon flex-shrink-0">
                  <i class="bi bi-cloud-upload"></i>
                </div>
                <div class="feature-content">
                  <h3>Cloud Backup</h3>
                  <p>Automatically sync data with cloud storage to prevent loss and access information anytime.</p>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>

    </section>
    <section id="call-to-action" class="call-to-action section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row content justify-content-center align-items-center position-relative">
          <div class="col-lg-8 mx-auto text-center">
            <h2 class="display-4 mb-4">Simplify Your Business with RX Square</h2>
            <p class="mb-4">Manage billing, inventory, and sales seamlessly with RX Square. Enhance efficiency, reduce errors, and grow your business with ease.</p>
            <a href="#" class="btn btn-cta">Get Started Now</a>
        </div>
        

          <!-- Abstract Background Elements -->
          <div class="shape shape-1">
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <path d="M47.1,-57.1C59.9,-45.6,68.5,-28.9,71.4,-10.9C74.2,7.1,71.3,26.3,61.5,41.1C51.7,55.9,35,66.2,16.9,69.2C-1.3,72.2,-21,67.8,-36.9,57.9C-52.8,48,-64.9,32.6,-69.1,15.1C-73.3,-2.4,-69.5,-22,-59.4,-37.1C-49.3,-52.2,-32.8,-62.9,-15.7,-64.9C1.5,-67,34.3,-68.5,47.1,-57.1Z" transform="translate(100 100)"></path>
            </svg>
          </div>

          <div class="shape shape-2">
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <path d="M41.3,-49.1C54.4,-39.3,66.6,-27.2,71.1,-12.1C75.6,3,72.4,20.9,63.3,34.4C54.2,47.9,39.2,56.9,23.2,62.3C7.1,67.7,-10,69.4,-24.8,64.1C-39.7,58.8,-52.3,46.5,-60.1,31.5C-67.9,16.4,-70.9,-1.4,-66.3,-16.6C-61.8,-31.8,-49.7,-44.3,-36.3,-54C-22.9,-63.7,-8.2,-70.6,3.6,-75.1C15.4,-79.6,28.2,-58.9,41.3,-49.1Z" transform="translate(100 100)"></path>
            </svg>
          </div>

          <!-- Dot Pattern Groups -->
          <div class="dots dots-1">
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
              <pattern id="dot-pattern" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <circle cx="2" cy="2" r="2" fill="currentColor"></circle>
              </pattern>
              <rect width="100" height="100" fill="url(#dot-pattern)"></rect>
            </svg>
          </div>

          <div class="dots dots-2">
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
              <pattern id="dot-pattern-2" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <circle cx="2" cy="2" r="2" fill="currentColor"></circle>
              </pattern>
              <rect width="100" height="100" fill="url(#dot-pattern-2)"></rect>
            </svg>
          </div>

          <div class="shape shape-3">
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <path d="M43.3,-57.1C57.4,-46.5,71.1,-32.6,75.3,-16.2C79.5,0.2,74.2,19.1,65.1,35.3C56,51.5,43.1,65,27.4,71.7C11.7,78.4,-6.8,78.3,-23.9,72.4C-41,66.5,-56.7,54.8,-65.4,39.2C-74.1,23.6,-75.8,4,-71.7,-13.2C-67.6,-30.4,-57.7,-45.2,-44.3,-56.1C-30.9,-67,-15.5,-74,0.7,-74.9C16.8,-75.8,33.7,-70.7,43.3,-57.1Z" transform="translate(100 100)"></path>
            </svg>
          </div>
        </div>

      </div>

    </section>
    <section id="testimonials" class="testimonials section light-background">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Customer Reviews</h2>
        <p>See what our customers say about RX Square's powerful business solutions</p>
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row g-5">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="testimonial-item">
              <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
              <h3>Arun Kumar</h3>
              <h4>Retail Store Owner</h4>
              <div class="stars">
                <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
              </div>
              <p>
                <i class="bi bi-quote quote-icon-left"></i>
                <span>RX Square has completely transformed how I manage my store. Billing is seamless, and inventory tracking is effortless. Highly recommended!</span>
                <i class="bi bi-quote quote-icon-right"></i>
              </p>
            </div>
          </div><!-- End testimonial item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div class="testimonial-item">
              <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
              <h3>Pooja Sharma</h3>
              <h4>Wholesale Business Owner</h4>
              <div class="stars">
                <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
              </div>
              <p>
                <i class="bi bi-quote quote-icon-left"></i>
                <span>With RX Square, I can handle bulk orders effortlessly. The automation features save me hours of manual work. Best decision ever!</span>
                <i class="bi bi-quote quote-icon-right"></i>
              </p>
            </div>
          </div><!-- End testimonial item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="300">
            <div class="testimonial-item">
              <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
              <h3>Vikram Patel</h3>
              <h4>Pharmacy Owner</h4>
              <div class="stars">
                <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
              </div>
              <p>
                <i class="bi bi-quote quote-icon-left"></i>
                <span>Managing prescriptions, stock levels, and invoicing has never been easier. RX Square is a must-have for pharmacy businesses!</span>
                <i class="bi bi-quote quote-icon-right"></i>
              </p>
            </div>
          </div><!-- End testimonial item -->

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="400">
            <div class="testimonial-item">
              <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
              <h3>Meena Reddy</h3>
              <h4>Supermarket Chain Owner</h4>
              <div class="stars">
                <i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i>
              </div>
              <p>
                <i class="bi bi-quote quote-icon-left"></i>
                <span>RX Square helped me scale my business efficiently. It’s reliable, fast, and packed with features that simplify operations.</span>
                <i class="bi bi-quote quote-icon-right"></i>
              </p>
            </div>
          </div><!-- End testimonial item -->

        </div>

      </div>

    </section>
    <section id="rx-square" class="services section light-background">

      <!-- Section Title -->
      <div class="container section-title" :data-aos="$client ? 'fade-up' : undefined">
        <h2>RX Square - The Ultimate Business Solution</h2>
        <p>One platform for seamless business operations, combining Accounts, HR, CRM, Marketing, Compliance, E-commerce, and more.</p>
      </div><!-- End Section Title -->
    
      <div class="container" data-aos="fade-up" data-aos-delay="100">
    
        <div class="row g-4">
    
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="service-card d-flex">
              <div class="icon flex-shrink-0">
                <i class="bi bi-cash-stack"></i>
              </div>
              <div>
                <h3>Advanced Billing & Accounts</h3>
                <p>Manage finances effortlessly with automated invoicing, multi-currency support, and real-time financial reports.</p>
              </div>
            </div>
          </div><!-- End Service Card -->
    
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
            <div class="service-card d-flex">
              <div class="icon flex-shrink-0">
                <i class="bi bi-people"></i>
              </div>
              <div>
                <h3>HR & Payroll</h3>
                <p>Streamline HR processes, track attendance, automate payroll, and manage employee records efficiently.</p>
              </div>
            </div>
          </div><!-- End Service Card -->
    
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="300">
            <div class="service-card d-flex">
              <div class="icon flex-shrink-0">
                <i class="bi bi-graph-up"></i>
              </div>
              <div>
                <h3>CRM & Marketing Automation</h3>
                <p>Enhance customer relationships, run targeted campaigns, push WhatsApp reports, and analyze engagement data.</p>
              </div>
            </div>
          </div><!-- End Service Card -->
    
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="400">
            <div class="service-card d-flex">
              <div class="icon flex-shrink-0">
                <i class="bi bi-shop-window"></i>
              </div>
              <div>
                <h3>Single-Click E-commerce</h3>
                <p>Launch your online store instantly with seamless inventory management, integrated payment gateways, and order tracking.</p>
              </div>
            </div>
          </div><!-- End Service Card -->
    
        </div>
    
      </div>
    
    </section>
</template>
  
<script setup>
const $client = process.client
  const activeTab = ref('features-tab-1');

function setActiveTab(tab) {
  activeTab.value = tab;
}
</script>
  
<style scoped>
  .features .nav-tabs {
    border: 0;
    background-color: color-mix(in srgb, var(--default-color), transparent 96%);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 50px;
    padding: 6px;
    width: auto;
  }
  
  .features .nav-item {
    margin: 0;
    padding: 0 5px 0 0;
  }
  
  .features .nav-item:last-child {
    padding-right: 0;
  }
  
  .features .nav-link {
    background-color: none;
    color: var(--heading-color);
    padding: 10px 30px;
    transition: 0.3s;
    border-radius: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    height: 100%;
    border: 0;
    margin: 0;
  }
  
  @media (max-width: 468px) {
    .features .nav-link {
      padding: 8px 20px;
    }
  }
  
  .features .nav-link i {
    padding-right: 15px;
    font-size: 48px;
  }
  
  .features .nav-link h4 {
    font-size: 14px;
    font-weight: 500;
    margin: 0;
  }
  
  .features .nav-link:hover {
    border-color: color-mix(in srgb, var(--default-color), transparent 80%);
  }
  
  .features .nav-link:hover h4 {
    color: var(--accent-color);
  }
  
  .features .nav-link.active {
    background-color: var(--accent-color);
    border-color: var(--accent-color);
  }
  
  .features .nav-link.active h4 {
    color: var(--contrast-color);
  }
  
  .features .tab-content {
    margin-top: 30px;
  }
  
  .features .tab-pane h3 {
    color: var(--heading-color);
    font-weight: 700;
    font-size: 32px;
    position: relative;
    margin-bottom: 20px;
    padding-bottom: 20px;
  }
  
  .features .tab-pane h3:after {
    content: "";
    position: absolute;
    display: block;
    width: 60px;
    height: 3px;
    background: var(--accent-color);
    left: 0;
    bottom: 0;
  }
  
  .features .tab-pane ul {
    list-style: none;
    padding: 0;
  }
  
  .features .tab-pane ul li {
    padding-top: 10px;
  }
  
  .features .tab-pane ul i {
    font-size: 20px;
    padding-right: 4px;
    color: var(--accent-color);
  }
  
  .features .tab-pane p:last-child {
    margin-bottom: 0;
  }
  </style>