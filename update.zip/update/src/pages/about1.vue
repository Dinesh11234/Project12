<template>
    <section id="about" class="about section">
      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row gy-4 align-items-center justify-content-between">
          <div class="col-xl-5" data-aos="fade-up" data-aos-delay="200">
            <span class="about-meta">WHY CHOOSE RX SQUARE?</span>
            <h2 class="about-title">Smart Billing & Retail Automation</h2>
            <p class="about-description">RX Square offers a powerful and seamless billing solution designed for retail businesses, streamlining operations with automation, real-time analytics, and cloud-based data management.</p>
            <div class="row feature-list-wrapper">
              <div class="col-md-6">
                <ul class="feature-list">
                  <li><i class="bi bi-check-circle-fill"></i> Fast & Secure Transactions</li>
                  <li><i class="bi bi-check-circle-fill"></i> Multi-Store & Multi-User Access</li>
                  <li><i class="bi bi-check-circle-fill"></i> AI-Powered Sales Analytics</li>
                </ul>
              </div>
              <div class="col-md-6">
                <ul class="feature-list">
                  <li><i class="bi bi-check-circle-fill"></i> Cloud & Offline Sync</li>
                  <li><i class="bi bi-check-circle-fill"></i> Automated Inventory Tracking</li>
                  <li><i class="bi bi-check-circle-fill"></i> 24/7 Customer Support</li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-xl-6" data-aos="fade-up" data-aos-delay="300">
            <div class="image-wrapper">
              <div class="images position-relative" data-aos="zoom-out" data-aos-delay="400">
                <img src="assets/img/about-5.webp" alt="Business Meeting" class="img-fluid main-image rounded-4">
                <img src="assets/img/about-2.webp" alt="Team Discussion" class="img-fluid small-image rounded-4">
              </div>
              <div class="experience-badge floating">
                <h3>100+ <span>Retailers</span></h3>
                <p>Already using RX Square</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
</template>