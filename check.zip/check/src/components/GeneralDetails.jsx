import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { fetchProduct, fetchPincodeDetails, fetchOccupancy, fetchSection, fetchRiskFactor, saveDraft, updateDraft, fetchEquipments } from '../api/api';
import '../styles/GeneralDetails.css';
import Select from "react-select";

const GeneralDetails = ({selectedPackages, user, userSegment}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({});
  const [mainData, setMainData] = useState([]); 
  const [areaOptions, setAreaOptions] = useState([]);
  const [parsedWorkflows, setParsedWorkflows] = useState([]);
  const [sections, setSections] = useState([]);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [nonIndustrial, setNonIndustrial] = useState(false);
  const [selectedZone, setSelectedZone] = useState(null); 
  const [componentValues] = useState({});
  let isSubmit = false;
  const [focusedComponent, setFocusedComponent] = useState(null);
  const [showComponentPopup, setShowComponentPopup] = useState(false);
  const [selectedComponents, setSelectedComponents] = useState([]);
  const [componentCovers, setComponentCovers] = useState({});
  const [isCopyAddressChecked, setIsCopyAddressChecked] = useState(false);
  const [packageSumInsured, setPackageSumInsured] = useState({});
  const [packageComponentValues, setPackageComponentValues] = useState({});
  const [submittedAddresses, setSubmittedAddresses] = useState([]);
  const [sectionData, setSectionData] = useState({});
  const [maxSumInsuredRules, setMaxSumInsuredRules] = useState(null);
  let errors = [];
  const [occupancyOptions, setOccupancyOptions] = useState([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [workflow, setWorkflow] = useState(0);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [popupFormData, setPopupFormData] = useState({});
  const [addressFormStep, setAddressFormStep] = useState(0);
  const title = location.state?.title || location.state?.editTitle;
  const [isEditMode, setIsEditMode] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [occupancyData, setOccupancyData] = useState([]);
  const [updatedRates, setUpdatedRates] = useState({});
  const [updateSI, setUpdateSI] = useState(0);
  const [updatePre, setUpdatePre] = useState(0);
  const fullSummary = location.state?.item || 0;
  const [isEditing, setIsEditing] = useState(location.state?.isEdit || location.state?.isDraft || false);
  const [productpackages, setProductPackages] = useState([]);
  const [riskFactor, setRiskFactor] = useState([]);
  const step = isEditing ? location.state?.currentStep: 0;
  user = isEditing ? location.state?.user : user;
  const id = location.state?.id || 0;
  const [componentData, setComponentData] = useState({});
  const [divisionOptions, setDivisionOptions] = useState([]);
  const [isRiskFactorExpanded, setIsRiskFactorExpanded] = useState(false);
  const [equipmentOptions, setEquipmentOptions] = useState([]);
  const [equipmentData, setEquipmentData] = useState([]);
  const [isMultiEquipment, setIsMultiEquipment] = useState(false);
  const [actualPackage, setActualPackage] = useState(null);
  const [isFloater, setIsFloater] = useState(false);
  const [activeCovers, setActiveCovers] = useState({});


  useEffect(() => {
    if (isEditing && fullSummary) {
      if(fullSummary[0].submittedAddress){
        setShowAddressForm(true);
        setAddressFormStep(step);
      }else{
        setCurrentStep(step);
      }

      const summaryData = fullSummary ? fullSummary[0] : fullSummary;
      setFormData({
        'Name': summaryData.name || '',
        'Mobile': summaryData.mobile || '',
        'Is Customer Individual or Corporate': summaryData.individualOrCorporate || '',
        'Gender': summaryData.gender || '',
        'Address Line 1': summaryData.addressLine1 || '',
        'Pincode': summaryData.pincode || '',
        'Area / Village': summaryData.areaVillage || '',
        'District / City': summaryData.districtCity || '',
        'State': summaryData.state || '',
        'PAN Number': summaryData.panNumber || '',
        'Date of Birth': summaryData.dateOfBirth || '',
        'Date of Incorporation': summaryData.dateOfIncorporation || '',
        'Risk Start Date': summaryData.policyPeriod || '',
        'Risk End Date': summaryData.policyEndPeriod || '',
      });

      setPopupFormData({
        'Gender': summaryData.gender || '',
        'Address Line 1': summaryData.addressLine1 || '',
        'Pincode': summaryData.pincode || '',
        'Area / Village': summaryData.areaVillage || '',
        'District / City': summaryData.districtCity || '',
        'State': summaryData.state || '',
        'SelectedNumber': summaryData.selectedNumber,
        'Type Of Construction': summaryData.typeOfConstruction,
        'Occupancy Type': summaryData.occupancyType,
        'Equipment Type': summaryData.equipmentType,
        'Age of the Risk Information': summaryData.ageOfRiskInformation,
        'Height of the Building (in meters)': summaryData.heightOfBuilding,
        'No. of Floors': summaryData.noOfFloors,
        'Equipment Details': summaryData.equipmentDetails,
        'natureOfProject': fullSummary.projectNature || '',
        'natureOfClaim': fullSummary.natureOfClaim || '',
        'yearOfClaim': fullSummary.yearOfClaim || '',
        'valueOfClaim': fullSummary.valueOfClaim || '',
        'postMeasures': fullSummary.postMeasures || '',
        'claimExperience': fullSummary.claimExperience || '',
        'hypothecation': fullSummary.hypothecation || '',
        'loadingDiscount_7': fullSummary.riskFactors || 0,
        'supportingDocuments': fullSummary.supportingDocuments,
        'supportingDocumentsURL': fullSummary.supportingDocumentsURL,

      });


      setMainData(summaryData);
      setIsRiskFactorExpanded(fullSummary.riskExpand || false);
      setIsMultiEquipment(summaryData.multiEquipment || false);
      setIsFloater(summaryData.floater || false);
      setProductPackages(summaryData.selectedpackages || []);
      setSelectedPackage(summaryData.selectedPackage || '');
      setSelectedComponents(summaryData.selectedComponents || []);
      setComponentCovers(summaryData.componentCovers || {});
      setPackageComponentValues(summaryData.packageComponentValues || {});
      setPackageSumInsured(summaryData.packageSumInsured || {});
      setMaxSumInsuredRules(summaryData.maxSumInsuredRules || {});
      setUpdatedRates(summaryData.updatedRates || {});
      setSectionData(summaryData.sections || {});
      if(summaryData.submittedAddress !== undefined) {
        setSubmittedAddresses(summaryData.submittedAddress ? [summaryData] : []);
      }
      else{
        setSubmittedAddresses([summaryData]);
      }
      
    }
  }, [isEditing, fullSummary]);

  const handleEquipmentChange = (selectedOptions) => {
    const optionsArray = Array.isArray(selectedOptions) ? selectedOptions : [selectedOptions].filter(Boolean);
    const equipmentPackages = optionsArray.map(option => `${option.label}-${selectedPackages[0]}`);
    setProductPackages(equipmentPackages);
    setPopupFormData(prev => {
      const existingDetails = prev['Equipment Details'] || [];
      
      const detailsMap = {};
      existingDetails.forEach(detail => {
        detailsMap[detail.equipment] = detail;
      });
      
      const newDetails = optionsArray.map((option, index) => {
        const equipmentName = option.label;
        
        if (detailsMap[equipmentName]) {
          return detailsMap[equipmentName];
        }

        
        return {
          equipment: equipmentName,
          make: '',
          model: '',
          serialNo: '',
          yom: ''
        };
      });
      
      return {
        ...prev,
        'Equipment Type': isMultiEquipment ? optionsArray : (optionsArray[0] || null),
        'Equipment Details': newDetails
      };
    });
  };
  

  const handleEquipmentDetailChange = (index, field, value) => {
    setPopupFormData(prev => {
      const equipmentDetails = [...(prev['Equipment Details'] || [])];
      
      if (!equipmentDetails[index]) {
        equipmentDetails[index] = {
          equipment: prev['Equipment Type'][index].label,
          make: '',
          model: '',
          serialNo: '',
          yom: '',
          si: ''
        };
      }
      
      equipmentDetails[index][field] = value;
      
      return {
        ...prev,
        'Equipment Details': equipmentDetails
      };
    });
  };

  const validateYOM = (value) => {
    return /^\d{0,4}$/.test(value);
  };

  const getZoneNumber = (zone) => {
    switch(zone) {
      case 'I': return '1';
      case 'II': return '2';
      case 'III': return '3';
      case 'IV': return '4';
      default: return '1';
    }
  };

  const getZone = (zone) => {
    switch(zone) {
      case 'I': return 'zone1';
      case 'II': return 'zone2';
      case 'III': return 'zone3';
      case 'IV': return 'zone4';
      default: return 'zone1';
    }
  };

  const getOccupancyRate = (cover, selectedOccupancy, section) => {
    if (!selectedOccupancy) return '0';

    const occupancySectionRate = section.occupancy_rate.split(', ');
    const occupancyMinSectionRate = section.occupancy_min_rate.split(', ');
    switch (cover) {
      case 'Basic':
        return selectedOccupancy[occupancySectionRate[0]] || '0';
      case 'STFI Cover':
        return selectedOccupancy[occupancySectionRate[1]] || '0';
      case 'Earthquake':
        const zone = popupFormData['Zone'] || 'I';
        const zoneNumber = getZoneNumber(zone);
        let totalCoverRate = 1;
        
        const factor = riskFactor
          .filter(factor => {
            const requiredSections = isEditing || isMultiEquipment ? productpackages : selectedPackages;
            return factor.section_name.split(', ').some(section => 
              requiredSections.includes(section)
            );
          })
          .find(factor => factor.type === 'Zone');

        if (factor?.type === 'Zone') {
          const zoneValues = JSON.parse(factor.zone);
          const currentZone = getZone(zone);
          totalCoverRate = 1 + (parseFloat(zoneValues[currentZone])/100) || 1;
        }
        let index;
        if(zone === 'II'){
          index = 3;
        }
        else if(zone === 'III'){
          index = 4;
        }
        else if(zone === 'IV'){
          index = 5;
        }
        else {
          index = 2
        }
        return selectedOccupancy[occupancySectionRate[index]] * totalCoverRate || '0';
      case 'Terrorism':
        return selectedOccupancy[occupancySectionRate[6]] || '0';
      default:
        return '0';
    }
  };

  const calculateTotalSumInsured = (pkg) => {
    const componentValues = packageComponentValues[pkg] || {};
    const totalSumInsured = Object.entries(componentValues)
      .filter(([key]) => !key.endsWith('_premium') && !key.endsWith('_terror'))
      .reduce((sum, [_, value]) => sum + (Number(value) || 0), 0);
    setPackageSumInsured((prev) => ({ ...prev, [pkg]: totalSumInsured }));
  };

  const initializeFormData = (workflows) => {
    const initialFormData = {};
    const today = new Date().toISOString().split('T')[0];
    const endDate = new Date();
    endDate.setFullYear(endDate.getFullYear() + 1);
    endDate.setDate(endDate.getDate() - 1);
    const formattedEndDate = endDate.toISOString().split('T')[0];
  
    workflows.forEach(parsedWorkflow => {
      if (parsedWorkflow.sections) {
        parsedWorkflow.sections.forEach(section => {
          section.fields.forEach(field => {
            if (field.default) {
              initialFormData[field.label] = field.default;
            } else if (field.label === 'Risk Start Date') {
              initialFormData[field.label] = today;
            } else if (field.label === 'Risk End Date') {
              initialFormData[field.label] = formattedEndDate;
            } else {
              initialFormData[field.label] = field.type === 'checkbox' ? false :
                                            field.type === 'number' ? 0 : '';
            }
          });
        });
      }
    });
    
    return initialFormData;
  };
  
  const initializePopupFormData = () => {
    const initialPopupData = {};
    
    parsedWorkflows.forEach(workflow => {
      if (workflow.sections) {
        workflow.sections.forEach(section => {
          section.fields.forEach(field => {
            if (!(field.label in initialPopupData)) {
              initialPopupData[field.label] = field.type === 'checkbox' ? false :
                                             field.type === 'number' ? 0 : '';
            }
          });
        });
      }
    });
    
    return initialPopupData;
  };

  useEffect(() => {
    if (!submittedAddresses.length && location.state?.item) {
      setSubmittedAddresses(location.state.item);
    }
    if(!showAddressForm){
      setCurrentStep(location.state?.currentStep || 0);
    }
    const getProduct = async () => {
      try {
        const productData = await fetchProduct();
        const workflowData = productData.find(item => item.name === title);
        if (workflowData) {
          const workflows = [];
          if (workflowData.workflow1) {
            workflows.push(JSON.parse(workflowData.workflow1).workflow1);
          }
          if (workflowData.workflow2) {
            workflows.push(JSON.parse(workflowData.workflow2).workflow2);
          }
          setParsedWorkflows(workflows);
          setWorkflow(workflows.length + 1);
          if(!isEditing && currentStep === 0){
          setFormData(initializeFormData(workflows));
          }
        }
      } catch (error) {
        console.error('Error fetching packages:', error);
      }
    };

    const getOccupancy = async () => {
      try {
        const data = await fetchOccupancy();
        const occupancyOptions = data.map(item => `${item.code}-${item.name}`);
        const occupancyData = data;
        setOccupancyOptions(occupancyOptions);
        setOccupancyData(occupancyData)
      } catch (error) {
        console.error('Error fetching occupancy details:', error);
      }
    };

    const getEquipment = async () => {
      try {
        const data = await fetchEquipments();
        const equipmentOptions = data.map(
          (item) => `${item.code}-${item.name}`
        );
        setEquipmentOptions(equipmentOptions);
        setEquipmentData(data);
      } catch (error) {
        console.error("Error fetching occupancy details:", error);
      }
    };

    const getRiskFactor = async () => {
      try {
        const data = await fetchRiskFactor();
        const filteredRiskFactors = data.filter(riskFactor => 
          riskFactor.product_name === title
        );
        setRiskFactor(filteredRiskFactors);
      } catch (error) {
        console.error('Error fetching Risk Factor details:', error);
      }
    };

    const getSections = async () => {
      try {
        const data = await fetchSection();
        setSections(data);
        const rulesObject = {};
        data.forEach(section => {
          if (section.max_sum_insured_data) {
            try {
              const maxSumInsuredData = JSON.parse(section.max_sum_insured_data);
              rulesObject[section.section_reference_name] = maxSumInsuredData;
            } catch (error) {
              console.error('Error parsing max_sum_insured_data for section:', section.section_reference_name, error);
            }
          }
        });
        setMaxSumInsuredRules(rulesObject);
      } catch (error) {
        console.error('Error fetching sections:', error);
      }
    };

    const initializeComponentCovers = () => {
      const initialCovers = {};
      sections.forEach((section) => {
        if (section.section_reference_name === selectedPackage) {
          section.components.split(', ').forEach((component) => {
            initialCovers[component] = section.covers.split(', ');
          });
        }
      });
      setComponentCovers(prevComponentCovers => {
        return { ...prevComponentCovers, ...initialCovers };
      });
    };
  
    initializeComponentCovers();
    calculateTotalSumInsured(selectedPackage);
    getOccupancy();
    getProduct();
    getSections();
    getRiskFactor();
    getEquipment();
  }, [componentValues, selectedPackage]);

  useEffect(() => {
    const getSectionComponentData = async () => {
      try {
        const sectionData = await fetchSection();
        const section = sectionData.find(s => s.section_reference_name === selectedPackage);
        
        if (section?.components_data) {
          const parsedData = JSON.parse(section.components_data);
          const dataMap = {};
          parsedData.forEach(comp => {
            dataMap[comp.name] = comp;
          });
          setComponentData(dataMap);
        }
      } catch (error) {
        console.error('Error fetching component data:', error);
      }
    };
  
    if (selectedPackage) {
      getSectionComponentData();
    }
  }, [selectedPackage]);

  const calculateAutoSumInsured = (component, section) => {
    if (!componentData[component]) return 0;
  
    const data = componentData[component];
    if (data.sumInsuredType !== 'Auto') return 0;
  
    // Get all components from the referenced section
    const components = data.sectionComponents.split(',');
    const percentage = parseFloat(data.sumInsuredPercentage) || 0;
  
    // Calculate total sum insured from referenced section components
    const totalSumInsured = components.reduce((sum, comp) => {
      const value = packageComponentValues[data.section]?.[comp] || 0;
      return sum + parseFloat(value);
    }, 0);

    // Calculate auto sum insured based on percentage
    const autoSumInsured = (totalSumInsured * percentage) / 100;
    const covers = componentCovers[component] || [];
    const type = popupFormData["Occupancy Type"] || popupFormData['Equipment Type'];
    const { totalPremium, terrorismPremium } = calculatePremium(
      { [component]: covers },
      type
    );

    // Update packageComponentValues with auto sum insured
    setPackageComponentValues(prevValues => ({
      ...prevValues,
      [section]: {
        ...(prevValues[section] || {}),
        [component]: autoSumInsured,
        [`${component}_premium`]: totalPremium,
        [`${component}_terror`]: terrorismPremium
      }
    }));

    // Update packageSumInsured for this section
    setPackageSumInsured(prevSumInsured => ({
      ...prevSumInsured,
      [section]: Object.entries(packageComponentValues[section] || {})
        .filter(([key]) => !key.endsWith('_premium')&&!key.endsWith('_terror'))
        .reduce((sum, [key, value]) => sum + parseFloat(value || 0), autoSumInsured)
    }));

    return autoSumInsured;
  };

  const handleChange = async (e) => {
    const { name, value, type, checked } = e.target;

    // Validate Name field to only contain letters
    if (name === 'Name' && !/^[A-Za-z\s]*$/.test(value)) {
      return;
    }
    if (name === 'Floater Policy') {
      setIsFloater(checked);
    }

    // Validate Mobile field to only contain numbers and be exactly 10 digits
    if (name === 'Mobile' && !/^\d{0,10}$/.test(value)) {
      return;
    }

    if(name === 'Pincode' && !/^\d{0,6}$/.test(value)) {
      return;
    }

    // Validate Address fields to only contain letters, numbers, hyphens, slashes, and commas
    if (name.startsWith('Address') && !/^[A-Za-z0-9\s\-\/,]*$/.test(value)) {
      return;
    }
    setFormData((prevData) => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Handle dependencies
    if (name === 'Pincode') {
      try {
        const pincodeDetails = await fetchPincodeDetails(value);
        if (pincodeDetails.length > 0) {
          const selectedPincode = pincodeDetails[0];
          const areas = pincodeDetails.map(detail => detail.area);
          setAreaOptions(areas);
          setFormData((prevData) => ({
            ...prevData,
            'District / City': selectedPincode.district,
            'State': selectedPincode.state,
            'Zone': selectedPincode.zone
          }));
        }
        else {
          if(value.length >= 6) {
            alert('Invalid Pincode');
          }
        }
      } catch (error) {
        console.error('Error fetching pincode details:', error);
      }
    }

    // Handle Risk Start Date and Risk End Date
    if (name === 'Risk Start Date') {
      const startDate = new Date(value);
      const endDate = new Date(startDate);
      endDate.setFullYear(startDate.getFullYear() + 1);
      endDate.setDate(endDate.getDate() - 1); // Ensure the end date is exactly one year minus one day
      setFormData((prevData) => ({
        ...prevData,
        'Risk Start Date': value,
        'Risk End Date': endDate.toISOString().split('T')[0]
      }));
    }
  };
  
  const handlePopupChange = async (e) => {
    const { name, value, type, checked } = e.target;

    // Validate Height of the Building (in meters) to only contain numbers and have a maximum of 6 digits
    if (name === 'Height of the Building (in meters)' && !/^\d{0,6}$/.test(value)) {
      return;
    }

    setNonIndustrial(false);

    if((name === "Occupancy Type" && title === "IAR") || (submittedAddresses.length > 1 && title === "IAR")) {
      const industry = occupancyData.find(item => item.code === parseInt(value.split('-')[0]));
      if(industry.risk_category === "Non-industrial"){
        setNonIndustrial(true);
      }
    }

    if(name === 'Multi Equipment') {
      setIsMultiEquipment(checked);
      
      // When toggling multi-equipment, preserve the equipment details
      if (!checked && Array.isArray(popupFormData['Equipment Type'])) {
        // If switching from multi to single, keep the first selection if any
        const firstSelection = popupFormData['Equipment Type'].length > 0 ? 
          popupFormData['Equipment Type'][0] : null;
        
        // Keep the Equipment Type as an array with one item for consistency
        setPopupFormData(prev => ({
          ...prev,
          'Equipment Type': firstSelection ? [firstSelection] : []
        }));
      } else if (checked && !Array.isArray(popupFormData['Equipment Type'])) {
        // If switching from single to multi, convert to array format
        const currentValue = popupFormData['Equipment Type'];
        if (currentValue) {
          const option = equipmentOptions
            .map(label => ({ label, value: label.toLowerCase() }))
            .find(opt => opt.value === currentValue.toLowerCase());
          
          if (option) {
            setPopupFormData(prev => ({
              ...prev,
              'Equipment Type': [option]
            }));
          } else {
            setPopupFormData(prev => ({
              ...prev,
              'Equipment Type': []
            }));
          }
        } else {
          setPopupFormData(prev => ({
            ...prev,
            'Equipment Type': []
          }));
        }
      }
    }    

    // Validate Address fields to only contain letters, numbers, hyphens, slashes, and commas
    if (name.startsWith('Address') && !/^[A-Za-z0-9\s\-\/,]*$/.test(value)) {
      return;
    }

    // Validate Age of the Risk Information to only contain numbers and have a maximum of 3 digits
    if (name === 'Age of the Risk Information' && !/^\d{0,3}$/.test(value)) {
      return;
    }

    if(name === 'Pincode' && !/^\d{0,6}$/.test(value)) {
      return;
    }

    // Validate No. of Floors to only contain numbers and have a maximum of 3 digits
    if (name === 'No. of Floors' && !/^\d{0,3}$/.test(value)) {
      return;
    }

    setPopupFormData((prevData) => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Handle dependencies
    if (name === 'Pincode') {
      try {
        const pincodeDetails = await fetchPincodeDetails(value);
        if (pincodeDetails.length > 0) {
          const selectedPincode = pincodeDetails[0];
          const areas = pincodeDetails.map(detail => detail.area);
          setAreaOptions(areas);
          
          if (selectedZone && value.length === 6) {
            const pincodeZone = selectedPincode.zone;
            
            if (selectedZone && pincodeZone && selectedZone !== pincodeZone) {
              alert(`This pincode belongs to Zone ${pincodeZone}, but you have selected Zone ${selectedZone}. Please correct your selection.`);
              
              setPopupFormData(prev => ({ 
                ...prev, 
                'Pincode': '' 
              }));
              return;
            }
          }
          
          setPopupFormData((prevData) => ({
            ...prevData,
            'District / City': selectedPincode.district,
            'State': selectedPincode.state,
            'Zone': selectedPincode.zone
          }));
        }
        else {
          if(value.length >= 6) {
            alert('Invalid Pincode');
          }
        }
      } catch (error) {
        console.error('Error fetching pincode details:', error);
      }
    }
  };

  const handleAddAddressClick = () => {
    setIsEditing(false);
    setShowAddressForm(true);
    setIsMultiEquipment(false);
    setAddressFormStep(0);
    setPopupFormData(initializePopupFormData());
    setSelectedPackage(null);
    setSelectedComponents([]);
    setComponentCovers({});
    setSectionData({});
    setUpdatePre(0);
    setUpdateSI(0);
    setIsCopyAddressChecked(false);
    setIsMultiEquipment(false);
    setPackageComponentValues({});
    setPackageSumInsured({});
    setUpdatedRates({});
    setIsEditMode(false);
    setEditIndex(null);
  };

  const handleEditAddressClick = (index) => {
    const addressToEdit = submittedAddresses[index];
    setSectionData(addressToEdit.sections || {});
    setPopupFormData({
      'Address Line 1': addressToEdit.addressLine1,
      'Pincode': addressToEdit.pincode,
      'Area / Village': addressToEdit.areaVillage,
      'District / City': addressToEdit.districtCity,
      'State': addressToEdit.state,
      'Type Of Construction': addressToEdit.typeOfConstruction,
      'Occupancy Type': addressToEdit.occupancyType,
      'Equipment Type': addressToEdit.equipmentType,
      'Age of the Risk Information': addressToEdit.ageOfRiskInformation,
      'Height of the Building (in meters)': addressToEdit.heightOfBuilding,
      'No. of Floors': addressToEdit.noOfFloors,
      'Equipment Details': addressToEdit.equipmentDetails,
      'SelectedNumber': addressToEdit.selectedNumber
    });
    setIsMultiEquipment(addressToEdit.multiEquipment);
    setIsFloater(addressToEdit.floater);
    setSelectedPackage(addressToEdit.selectedPackage);
    setSelectedComponents(addressToEdit.selectedComponents);
    setComponentCovers(addressToEdit.componentCovers);
    setPackageComponentValues(addressToEdit.packageComponentValues);
    setPackageSumInsured(addressToEdit.packageSumInsured); // Set the sum insured for each section
    setUpdatedRates(addressToEdit.updatedRates || {}); // Set the updated rates
    setShowAddressForm(true);
    setAddressFormStep(0);
    setIsEditMode(true);
    setEditIndex(index);
  };

  const handleCopyAddressChange = async(e) => {
    const { checked } = e.target;
    const pincodeDetails = await fetchPincodeDetails(mainData.pincode);
    setIsCopyAddressChecked(checked);
    const selectedPincode = pincodeDetails[0];
    if (checked) {
      setPopupFormData({
        'Address Line 1': mainData.addressLine1,
        'Pincode': mainData.pincode,
        'Area / Village': mainData.areaVillage,
        'District / City': mainData.districtCity,
        'State': mainData.state,
        'Zone': selectedPincode.zone
      });
    } else {
      setPopupFormData({
        'Address Line 1': '',
        'Pincode': '',
        'Area / Village': '',
        'District / City': '',
        'State': ''
      });
    }
  };

  const getMinRiskStartDate = () => {
    const today = new Date();
    const minDate = new Date(today);
    minDate.setDate(today.getDate() - 15);
    return minDate.toISOString().split('T')[0];
  };

  const getMaxRiskStartDate = () => {
    const today = new Date();
    const maxDate = new Date(today);
    maxDate.setMonth(today.getMonth() + 1);
    return maxDate.toISOString().split('T')[0];
  };

  const getMaxDateOfBirth = () => {
    const today = new Date();
    const maxDate = new Date(today.setFullYear(today.getFullYear() - 18));
    return maxDate.toISOString().split('T')[0];
  };

  const validatePopupFields = () => {
    const newErrors = [];

    if ('Address Line 1' in popupFormData) {
      if (!popupFormData['Address Line 1'] || popupFormData['Address Line 1'].length < 6) {
        newErrors.push('Address Line 1 should be at least 6 characters long.');
      }
    }

    if(nonIndustrial){
      newErrors.push('Select Industrial Occupancy');
    }

    const workflowFields = {};
    parsedWorkflows.forEach(workflow => {
      if (workflow.sections) {
        workflow.sections.forEach(section => {
          section.fields.forEach(field => {
            workflowFields[field.label] = field;
          });
        });
      }
    });
    
    // Fields required for address based on current workflow
    let requiredAddressFields = [];
    // Validate required address fields that are visible in current workflow
    requiredAddressFields.forEach(fieldName => {
      // Only validate if the field is visible in current workflow or is a basic field
      const isBasicField = ['Address Line 1', 'Pincode', 'Area / Village', 'District / City', 'State'].includes(fieldName);
      if ((fieldName in popupFormData) && (isBasicField || fieldName)) {
        if (!popupFormData[fieldName] || popupFormData[fieldName].toString().trim() === '') {
          newErrors.push(`${fieldName} is required.`);
        } else {
          // Field-specific validations
          switch (fieldName) {
            case 'Address Line 1':
              if (popupFormData[fieldName].length < 6) {
                newErrors.push('Address Line 1 should be at least 6 characters long.');
              }
              break;
            case 'Pincode':
              if (!/^\d{6}$/.test(popupFormData[fieldName])) {
                newErrors.push('Enter a valid Pincode.');
              }
              break;
            case 'Age of the Risk Information':
              if (isNaN(popupFormData[fieldName]) || popupFormData[fieldName] <= 0) {
                newErrors.push('Age of the Risk Information must be a positive number.');
              }
              break;
            // Add other field-specific validations as needed
          }
        }
      }
    });

    const currentWorkflowFields = {};
    if (parsedWorkflows[currentStep]?.sections) {
      parsedWorkflows[currentStep].sections.forEach(section => {
        section.fields.forEach(field => {
          currentWorkflowFields[field.label] = field;
        });
      });
    }
    
    // Additional validations from workflow fields - only validate fields in current workflow
    Object.entries(currentWorkflowFields).forEach(([fieldName, fieldConfig]) => {
      // Skip fields already validated above and only check fields visible in current workflow
      if (!requiredAddressFields.includes(fieldName) && 
          fieldConfig.required && 
          fieldName) {
        
        const value = popupFormData[fieldName];
        
        if (value === undefined || value === null || value.toString().trim() === '') {
          newErrors.push(`${fieldName} is required.`);
        } else {
          // Type-specific validations
          switch (fieldConfig.type) {
            case 'number':
              if (isNaN(value)) {
                newErrors.push(`${fieldName} must be a number.`);
              }
              break;
            case 'dropdown':
              if (value === '') {
                newErrors.push(`Please select ${fieldName}.`);
              }
              break;
          }
        }
      }
    });
  
    errors = newErrors;
    return newErrors.length === 0;
  };
  
  const validateFields = () => {
    const newErrors = [];
    // Get all fields from workflow to know what we should validate
    const workflowFields = {};
    parsedWorkflows.forEach(workflow => {
      if (workflow.sections) {
        workflow.sections.forEach(section => {
          section.fields.forEach(field => {
            workflowFields[field.label] = field;
          });
        });
      }
    });
    
    // Common field validations
    if ('Name' in formData) {
      if (!/^[A-Za-z ]{3,}$/.test(formData['Name'])) {
        newErrors.push('Name should have at least three characters and only letters and spaces.');
      }
    }
  
    if ('Mobile' in formData) {
      if (!/^\d{10}$/.test(formData['Mobile'])) {
        newErrors.push('Mobile should have exactly 10 digits.');
      }
    }
  
    if ('Pincode' in formData) {
      if (!/^\d{6}$/.test(formData['Pincode'])) {
        newErrors.push('Enter a valid Pincode.');
      }
    }
    
    if ('PAN Number' in formData) {
      if (!formData['PAN Number']) {
        newErrors.push('PAN Number is required.');
      } else if (!/^[A-Za-z0-9]*$/.test(formData['PAN Number'])) {
        newErrors.push('PAN Number should only contain letters and numbers.');
      }
    }
  
    if ('Address Line 1' in formData) {
      if (!formData['Address Line 1'] || formData['Address Line 1'].length < 6) {
        newErrors.push('Address Line 1 should be at least 6 characters long.');
      }
    }
  
    // Check if either Date of Birth or Date of Incorporation is provided (if visible)
    const dobVisible = 'Date of Birth';
    const doiVisible = 'Date of Incorporation';
    
    if ((dobVisible || doiVisible) && 
        (!formData['Date of Birth'] && !formData['Date of Incorporation'])) {
      newErrors.push('Either Date of Birth or Date of Incorporation must be filled.');
    }

    const currentWorkflowFields = {};
    if (parsedWorkflows[currentStep]?.sections) {
      parsedWorkflows[currentStep].sections.forEach(section => {
        section.fields.forEach(field => {
          currentWorkflowFields[field.label] = field;
        });
      });
    }
  
    // Validate all workflow fields that are visible in current workflow
    Object.entries(currentWorkflowFields).forEach(([fieldName, fieldConfig]) => {
      // Skip fields already validated above
      const alreadyValidated = ['Name', 'Mobile', 'Pincode', 'PAN Number', 'Address Line 1', 
                                'Date of Birth', 'Date of Incorporation'];
      
      if (!alreadyValidated.includes(fieldName) && 
          fieldConfig.required && 
          fieldName) {
        
        // Check if the field exists in formData
        if (fieldName in formData) {
          const value = formData[fieldName];
          
          // Check if value is empty
          if (value === undefined || value === null || value.toString().trim() === '') {
            newErrors.push(`${fieldName} is required.`);
          } else {
            // Type-specific validations
            switch (fieldConfig.type) {
              case 'number':
                if (isNaN(value)) {
                  newErrors.push(`${fieldName} must be a number.`);
                }
                break;
              case 'date':
                if (!isValidDate(value)) {
                  newErrors.push(`${fieldName} must be a valid date.`);
                }
                break;
              case 'dropdown':
                if (value === '') {
                  newErrors.push(`Please select ${fieldName}.`);
                }
                break;
            }
          }
        }
      }
    });
    errors = newErrors;
    return newErrors.length === 0;
  };

  const isValidDate = (dateString) => {
    const date = new Date(dateString);
    return date instanceof Date && !isNaN(date);
  };

  const validateSectionAccess = (pkg) => {
    const sectionRules = maxSumInsuredRules[pkg];
    if (!sectionRules) return true;
  
    if (sectionRules.type === 'Section Based' && sectionRules.section) {
      // Check both submittedAddresses and current packageSumInsured
      const referencedSectionSumInsured = packageSumInsured[sectionRules.section] || 0;
      
      // Check if the required section has a sum insured value
      if (referencedSectionSumInsured <= 0) {
        return false;
      }
    }
    return true;
  };

  const handlePackageClick = (pkg) => {
    if (!validateSectionAccess(pkg)) {
      alert(`You need to add sum insured for ${maxSumInsuredRules.section} first.`);
      return;
    }
    if(isMultiEquipment){
      const pack = "Contractor's Plant and Machinery";
      setSelectedPackage(pack);
      setActualPackage(pkg);
    }
    else{
      setSelectedPackage(pkg);
    }
    const firstComponent = sections
      .find(section => section.section_reference_name === pkg)
      ?.components.split(', ')[0];
    setFocusedComponent(firstComponent);
    setAddressFormStep(2);
  };

  const handleComponentValueChange = (pkg, component, value, equipment) => {
    const sect = isMultiEquipment ? equipment : pkg;
    setPackageComponentValues((prevValues) => {
      const newValues = { ...prevValues };
      if (!newValues[sect]) {
        newValues[sect] = {};
      }
  
      // Even if it's an Auto type, allow manual entry
      newValues[sect][component] = value;
  
      // Calculate premium
      const covers = componentCovers[component] || [];
      const type = popupFormData["Occupancy Type"] || popupFormData['Equipment Type'];
      const {totalPremium, terrorismPremium} = calculatePremium({ [component]: covers }, type);
      calculateTotalSumInsured(sect);
      newValues[sect][`${component}_premium`] = totalPremium;
      newValues[sect][`${component}_terror`] = terrorismPremium;
      return newValues;
    });
  };

  const handleComponentSelectionChange = (component) => {
    setSelectedComponents((prevSelected) => {
      if (prevSelected.includes(component)) {
        return prevSelected.filter((item) => item !== component);
      } else {
        return [...prevSelected, component];
      }
    });
  };

  const handleCoverChange = (component, cover, checked) => {
    // Update active covers status first
    setActiveCovers(prevActiveCovers => {
      const newActiveCovers = { ...prevActiveCovers };
      if (!newActiveCovers[selectedPackage]) {
        newActiveCovers[selectedPackage] = {};
      }
      newActiveCovers[selectedPackage][cover] = checked ? "active" : "inactive";
      return newActiveCovers;
    });
  
    setComponentCovers((prevCovers) => {
      const allCovers = { ...prevCovers };
      const hasValue = packageComponentValues[selectedPackage]?.[component];
  
      if (!hasValue) {
        return prevCovers;
      }
  
      if (checked) {
        const componentCover = prevCovers[component] || [];
        allCovers[component] = componentCover.includes(cover) ? componentCover : [...componentCover, cover];
      } else {
        Object.keys(allCovers).forEach(comp => {
          if (allCovers[comp]) {
            allCovers[comp] = allCovers[comp].filter(c => c !== cover);
          }
        });
      }
  
      const type = popupFormData["Occupancy Type"] || popupFormData['Equipment Type'];
      const { totalPremium, terrorismPremium } = calculatePremium({ [component]: allCovers[component] }, type);
      
      setPackageComponentValues((prevValues) => {
        const newValues = { ...prevValues };
        if (!newValues[selectedPackage]) {
          newValues[selectedPackage] = {};
        }
  
        newValues[selectedPackage][`${component}_premium`] = totalPremium;
        newValues[selectedPackage][`${component}_terror`] = terrorismPremium;
  
        if (!checked) {
          Object.keys(allCovers).forEach(comp => {
            if (comp !== component && packageComponentValues[selectedPackage]?.[comp]) {
              const { totalPremium, terrorismPremium } = calculatePremium({ [comp]: allCovers[comp] }, type);
              newValues[selectedPackage][`${comp}_premium`] = totalPremium;
              newValues[selectedPackage][`${comp}_terror`] = terrorismPremium;
            }
          });
        }
  
        calculateTotalSumInsured(selectedPackage);
        return newValues;
      });
  
      return allCovers;
    });
  
    setUpdatedRates((prevRates) => {
      const newRates = { ...prevRates };
      
      if (checked) {
        newRates[`${component}-${cover}`] = prevRates[`${component}-${cover}`] || 0;
      } else {
        Object.keys(prevRates).forEach(key => {
          if (key.endsWith(`-${cover}`)) {
            newRates[key] = undefined;
          }
        });
      }
      
      return newRates;
    });
  };

  const calculatePremium = (covers, occupan) => {
    let totalPremium = 0;
    let terrorismPremium = 0;
    const selectedOccupancyCode = isMultiEquipment ? actualPackage.split("-")[0] : occupan.split("-")[0];
    const selectedOccupancy = isMultiEquipment ? undefined : occupancyData.find(occupancy => occupancy.code == selectedOccupancyCode);
    const selectedEquipmentCode = isMultiEquipment ? actualPackage.split("-")[0] : occupan.split("-")[0];
    const selectedEquipment = equipmentData.find(equipment => equipment.code == selectedEquipmentCode);
    const section = sections.find(section => section.section_reference_name === selectedPackage);
    const coverRateTypes = JSON.parse(section.cover_rate_types || '[]');
    
    const factor = riskFactor
    .filter(factor => {
      const requiredSections = isEditing || isMultiEquipment ? productpackages : selectedPackages;
      return factor.section_name.split(', ').some(section => 
        requiredSections.includes(section)
      );
    })
    .find(factor => factor.type === 'Zone');

    const factortype = factor ? factor.type : '';
  
    Object.keys(covers).forEach((component) => {
      if (section.components.split(', ').includes(component)) {
        covers[component].forEach((cover) => {
          const value = packageComponentValues[isMultiEquipment ? actualPackage : selectedPackage]?.[component] || 0;
          let coverRate = updatedRates[`${component}-${cover}`] || 0;

          const autoRateCover = coverRateTypes.find(rt => rt.cover === cover && rt.rateType === 'Auto');

          if (autoRateCover) {
            const componentRates = autoRateCover.coverComponents.map(compCover => {
              if (compCover === 'Basic' || compCover === 'STFI Cover' || compCover === 'Earthquake' || compCover === 'Terrorism') {
                switch (compCover) {
                  case 'Basic':
                    return selectedOccupancy?selectedOccupancy.IIB_basic : selectedEquipment.basic || 0;
                  case 'STFI Cover':
                    return (
                      selectedOccupancy?selectedOccupancy.IIB_stfi : selectedEquipment.stfi || 0
                    );
                  case 'Earthquake':
                    const zone = popupFormData['Zone'] || 'I';
                    const zoneNumber = getZoneNumber(zone);
                    return selectedOccupancy?selectedOccupancy[`IIB_eq${zoneNumber}`] : selectedEquipment[`eq${zoneNumber}`] || 0;
                  case 'Terrorism':
                    return (
                      selectedOccupancy?selectedOccupancy.IIB_terrorism :
                      selectedEquipment.terrorism ||
                      0
                    );
                  default:
                    return 0;
                }
              } else {
                return section.direct_rate.split(', ')
                  .find(rate => rate.startsWith(`${compCover}-`))?.split('-')[1] || 0;
              }
            });
            
            // Sum up all component rates
            coverRate = componentRates.reduce((sum, rate) => sum + parseFloat(rate), 0);
          }
          else if (!coverRate) {
            if (
              section.rate_type === "occupancy" ||
              section.rate_type === "equipments"
            ) {
              switch (cover) {
                case "STFI Cover":
                  coverRate =
                    selectedOccupancy?selectedOccupancy.IIB_stfi: selectedEquipment.stfi || 0;
                  break;
                case "Earthquake":
                  const zone = popupFormData["Zone"] || "I";
                  const zoneNumber = getZoneNumber(zone);
                  let totalCoverRate = 0;
                  if (factortype === "Zone") {
                    const zoneValues = JSON.parse(factor.zone);
                    const currentZone = getZone(zone);
                    totalCoverRate =
                      parseFloat(zoneValues[currentZone]) / 100 || 1;
                  }
                  const type = selectedOccupancy
                    ? selectedOccupancy[`IIB_eq${zoneNumber}`]
                    : selectedEquipment[`eq${zoneNumber}`];
                  coverRate = type 
                  break;
                case "Basic":
                  coverRate =
                    selectedOccupancy?selectedOccupancy.IIB_basic : selectedEquipment.basic || 0;
                  break;
                case "Terrorism":
                  coverRate =
                    selectedOccupancy?selectedOccupancy.IIB_terrorism :
                    selectedEquipment.terrorism ||
                    0;
                  break;
                default:
                  coverRate = 0;
              }
            } else if (section.rate_type === "direct") {
              coverRate =
                section.direct_rate
                  .split(", ")
                  .find((rate) => rate.startsWith(`${cover}-`))
                  ?.split("-")[1] || 0;
            }
          }
  
          // Apply loading/discount percentage if exists for this cover
          const riskFactors = riskFactor.filter(rf => 
            rf.apply_to.split(', ').includes(cover) && 
            rf.section_name.split(', ').includes(selectedPackage) &&
            popupFormData[`loadingDiscount_${rf.risk_factor_id}`]
          );

          let loadingDiscount = 0;
          riskFactors.forEach(rf => {
            const loadingValue = parseFloat(popupFormData[`loadingDiscount_${rf.risk_factor_id}`]);
            
            if (!isNaN(loadingValue)) {
              // Convert percentage to multiplier (e.g., 10% -> 1.1, -10% -> 0.9)
              const multiplier = (loadingValue / 100);
              loadingDiscount += multiplier;
            }
          });

          coverRate = coverRate * (1+loadingDiscount);

          const premium = (value * coverRate) / 1000;

          if (cover === 'Terrorism') {
            terrorismPremium += premium;
          } 
          totalPremium += premium;
        });
      }
    });
  
    return {totalPremium, terrorismPremium};
  };

  const calculatePolicyRiskFactors = (sectionPremium, sectionName, address) => {
    const policyRiskFactors = riskFactor.filter(factor => {
      const extractBaseSectionName = (fullSectionName) => {
        const parts = fullSectionName.split('-');
        return parts[parts.length - 1].trim();
      };
      
      // Check if this factor applies to the current section
      return factor.factor_type === 'Policy' && 
             factor.section_name.split(', ').some(section => 
               extractBaseSectionName(section) === extractBaseSectionName(sectionName)
             );
    });
    
    let finalPremium = sectionPremium;
    
    policyRiskFactors.forEach(factor => {
      const loadingValue = popupFormData[`loadingDiscount_${factor.risk_factor_id}`];
      if (loadingValue) {
        const percentage = parseFloat(loadingValue) / 100;
        
        if (factor.calculation_type === 'Add') {
          // Apply add calculation only for this section
          const covers = address.sectionCovers[sectionName] || [];
          const matchingCovers = covers.filter(cover => 
            cover.is_active && cover.cover === factor.apply_to
          );
          
          let additionalPremium = 0;
          matchingCovers.forEach(cover => {
            const sumInsured = address.packageSumInsured[sectionName] || 0;
            const coverPremium = sumInsured * (cover.rate / 1000);
            additionalPremium += coverPremium * percentage;
          });
          
          finalPremium += additionalPremium;
        } else if (factor.calculation_type === 'Multiply') {
          finalPremium = finalPremium * (1 + percentage); // Apply percentage correctly
        }
      }
    });
    
    return finalPremium;
  };
  
  const handleNext = () => {
    // const isValid = currentStep === 1 ? true : validateFields();
    const isValid = true;
   if (isValid) {
      const newFormData = {
        name: formData['Name'],
        mobile: formData['Mobile'],
        addressLine1: formData['Address Line 1'],
        areaVillage: formData['Area / Village'],
        districtCity: formData['District / City'],
        state: formData['State'],
        floaterPolicy: formData['Floater Policy'],
        pincode: formData['Pincode'],
        panNumber: formData['PAN Number'],
        dateOfBirth: formData['Date of Birth'],
        dateOfIncorporation: formData['Date of Incorporation'],
        riskStartDate: formData['Risk Start Date'],
        riskEndDate: formData['Risk End Date'],
        individualOrCorporate: formData['Is Customer Individual or Corporate'],
        maleOrFemale: formData['Gender'],
      };
  
      setMainData(newFormData);

      if(currentStep === 1 && submittedAddresses.length === 0) {
        alert("Please add the Risk Address");
        return;
      }
  
      if (currentStep < workflow - 1) {
        setCurrentStep(currentStep + 1);
      }      
    } else {
      alert(errors.map(error => `• ${error}`).join('\n'));
    }
    
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleStepClick = (stepIndex) => {
    const isValid = validateFields();
    if (isValid) {
      setCurrentStep(stepIndex);
    } else {
      alert(errors.map(error => `• ${error}`).join('\n'));
    }
  };

  const validateSectionSumInsured = () => {
    // Check if all selected components have sum insured values
    if(isSubmit){
      const requiredSections = isEditing || isMultiEquipment ? productpackages : selectedPackages;
    
      // Check if each section has a sum insured value
      requiredSections[0] = title === 'SFSP' ? requiredSections[0] = 'SFSP-FIRE': requiredSections[0];
      const hasAllSectionValues = requiredSections.every(section => {
        const sectionSumInsured = packageSumInsured[section] || 0;
        return sectionSumInsured > 0;
      });

      if (!hasAllSectionValues) {
        alert('Please enter sum insured values for all sections');
        return false;
      }
    }
  
    // Check percentage limits
    const sectionRules = maxSumInsuredRules[selectedPackage];
    if (sectionRules?.type === 'Section Based' && sectionRules.section) {
      const referencedSectionSumInsured = packageSumInsured[sectionRules.section] || 0;
      const componentValues = packageComponentValues[selectedPackage] || {};
      const currentSumInsured = Object.entries(componentValues)
        .filter(([key]) => !key.endsWith('_premium')&&!key.endsWith('_terror'))
        .reduce((total, [_, value]) => total + (Number(value) || 0), 0);
      
      if (sectionRules.sumInsuredPercentage) {
        const maxAllowed = (referencedSectionSumInsured * parseFloat(sectionRules.sumInsuredPercentage)) / 100;

        if (currentSumInsured > maxAllowed) {
          alert(`Sum insured cannot exceed ${sectionRules.sumInsuredPercentage}% of ${sectionRules.section}`);
          return false;
        }
      }
    }
    else if(sectionRules?.type === 'Direct'){
      const componentValues = packageComponentValues[selectedPackage] || {};
      const currentSumInsured = Object.entries(componentValues)
        .filter(([key]) => !key.endsWith('_premium')&&!key.endsWith('_terror'))
        .reduce((total, [_, value]) => total + (Number(value) || 0), 0);
      if (sectionRules.sumInsuredValue) {
        if (currentSumInsured > sectionRules.sumInsuredValue) {
          alert(`Sum insured cannot exceed ${sectionRules.sumInsuredValue} Limit`);
          return false;
        }
      }
    }
  
    return true;
  };

  const validateRiskFactors = () => {
    // Get risk factors for all selected packages instead of just current section
    const selectedSections = isEditing || isMultiEquipment ? productpackages : selectedPackages;
    const applicableRiskFactors = riskFactor.filter(factor => 
      factor.section_name.split(', ').some(section => selectedSections.includes(section)) &&
      factor.factor_type === 'Location'
    );
  
    // If no risk factors, validation passes
    if (applicableRiskFactors.length === 0) return true;
  
    let isValid = true;
    const errors = [];
  
    applicableRiskFactors.forEach(factor => {
      // Skip Zone type factors as they are auto-populated
      if (factor.type === 'Zone') return;
  
      // For Direct and List type factors
      if (factor.type !== 'Free Entry' && (factor.type === 'Direct' || factor.list)) {
        const selectedValue = popupFormData[`riskFactorList_${factor.risk_factor_id}`];
        if (!selectedValue) {
          errors.push(`Please select a value for ${factor.risk_factor_name}`);
          isValid = false;
        }
  
        // Check if loading/discount value is required
        const loadingValue = popupFormData[`loadingDiscount_${factor.risk_factor_id}`];
        
        if (factor.type !== 'Direct' && (loadingValue === undefined || loadingValue === '')) {
          errors.push(`Please enter loading/discount value for ${factor.risk_factor_name}`);
          isValid = false;
        } else {
          const numValue = parseFloat(loadingValue);
  
          if (factor.type === 'Direct') {
            // For Direct type, check against list_values
            if (selectedValue && factor.list_values) {
              const listValues = JSON.parse(factor.list_values);
              const minLimit = parseFloat(listValues[selectedValue]?.min || 0);
              if (numValue < minLimit) {
                errors.push(`${factor.risk_factor_name} value must be at least ${minLimit}% for ${selectedValue}`);
                isValid = false;
              }
            }
          } else if (factor.type === 'Limit') {
            // For Limit type, check value ranges from list_values
            if (selectedValue && factor.list_values) {
              const listValues = JSON.parse(factor.list_values);
              const optionValues = listValues[selectedValue];
              if (optionValues) {
                const minLimit = parseFloat(optionValues.min);
                const maxLimit = parseFloat(optionValues.max);
                if (numValue < minLimit || numValue > maxLimit) {
                  errors.push(`${factor.risk_factor_name} value must be between ${minLimit}% and ${maxLimit}% for ${selectedValue}`);
                  isValid = false;
                }
              }
            }
          }
        }
      }
  
      // For Free Entry type factors
      if (factor.type === 'Free Entry') {
        const loadingValue = popupFormData[`loadingDiscount_${factor.risk_factor_id}`];
        if (loadingValue === undefined || loadingValue === '') {
          errors.push(`Please enter loading/discount value for ${factor.risk_factor_name}`);
          isValid = false;
        } else {
          const numValue = parseFloat(loadingValue);
          const minLimit = parseFloat(factor.min);
          const maxLimit = parseFloat(factor.max);
          if (numValue < minLimit || numValue > maxLimit) {
            errors.push(`${factor.risk_factor_name} value must be between ${minLimit}% and ${maxLimit}%`);
            isValid = false;
          }
        }
      }
    });
  
    if (!isValid) {
      alert(errors.join('\n'));
    }
  
    return isValid;
  };

  const formatDate = (isoString) => {
    const date = new Date(isoString);
    return date.toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const handleSaveDraft = async () => {
    try {
      const now = formatDate(new Date().toISOString());
  
      // Create base form data
      const mainFormData = {
        name: formData["Name"] || "",
        mobile: formData["Mobile"] || "",
        individualOrCorporate: formData["Is Customer Individual or Corporate"] || "",
        gender: formData["Gender"] || "",
        panNumber: formData["PAN Number"] || "",
        dateOfBirth: formData["Date of Birth"] || "",
        dateOfIncorporation: formData["Date of Incorporation"] || "",
        policyPeriod: formData["Risk Start Date"] || "",
        policyEndPeriod: formData["Risk End Date"] || "",
        title: title || "",
        selectedpackages: isEditing || isMultiEquipment ? productpackages : selectedPackages,
        isEdited: isEditing || false,
        editId: isEditing ? id : null,
        submittedAddress: false,
        addressLine1: formData["Address Line 1"] || "",
        areaVillage: formData["Area / Village"] || "",
        districtCity: formData["District / City"] || "",
        state: formData["State"] || "",
        pincode: formData["Pincode"] || "",
        typeOfConstruction: formData["Type Of Construction"] || "",
        occupancyType: formData["Occupancy Type"] || "",
        equipmentType: formData["Equipment Type"] || "",
        ageOfRiskInformation: formData["Age of the Risk Information"] || "",
        heightOfBuilding: formData["Height of the Building (in meters)"] || "",
        noOfFloors: formData["No. of Floors"] || "",
      };
  
      // Initialize draft data
      let draftData = [];
  
      // If in address form and on step 2 (components/covers step)
      if (showAddressForm) {
        const currentAddress = {
          ...mainFormData,
          addressLine1: popupFormData['Address Line 1'] || '',
          areaVillage: popupFormData['Area / Village'] || '',
          districtCity: popupFormData['District / City'] || '',
          state: popupFormData['State'] || '',
          pincode: popupFormData['Pincode'] || '',
          typeOfConstruction: popupFormData['Type Of Construction'] || '',
          occupancyType: popupFormData['Occupancy Type'] || '',
          equipmentType: popupFormData['Equipment Type'] || '',
          ageOfRiskInformation: popupFormData['Age of the Risk Information'] || '',
          heightOfBuilding: popupFormData['Height of the Building (in meters)'] || '',
          noOfFloors: popupFormData['No. of Floors'] || '',
          selectedPackage: selectedPackage || '',
          selectedComponents: selectedComponents || [],
          componentCovers: componentCovers || {},
          packageComponentValues: packageComponentValues || {},
          updatedRates: updatedRates || {},
          packageSumInsured: packageSumInsured || {},
          maxSumInsuredRules: maxSumInsuredRules || {},
          riskFactor: riskFactor || {},
          sections: sectionData || {},
          submittedAddress: true,
          currentStep: addressFormStep,
          totalSumInsured: Object.values(packageSumInsured).reduce((sum, val) => sum + (Number(val) || 0), 0),
          premium: Object.values(sectionData).reduce((sum, section) => sum + (Number(section.premium) || 0), 0)
        };
  
        if (isEditMode) {
          draftData = [...submittedAddresses];
          draftData[editIndex] = currentAddress;
        } else {
          draftData = [currentAddress];
        }
      } else {
        // If not in component step or not in address form, save main data only
        draftData = [{
          ...mainFormData,
          totalSumInsured: 0,
          premium: 0,
          sections: {},
          packageComponentValues: {},
          packageSumInsured: {},
          currentStep: showAddressForm ? addressFormStep : currentStep
        }];
      }
  
      // Convert data to JSON string
      const addressesJSON = JSON.stringify(draftData);
  
      // Check if we're editing an existing draft
      if (location.state?.isDraft && location.state?.id) {
        // Update existing draft
        const result = await updateDraft(
          location.state.id,
          draftData,
          user,
          currentStep,
          addressesJSON,
          now
        );
        alert('Draft updated successfully!');
      } else {
        // Save new draft
        const result = await saveDraft(
          draftData,
          user,
          currentStep,
          addressesJSON,
          now
        );
        alert('Draft saved successfully!');
      }
  
    } catch (error) {
      console.error('Error saving/updating draft:', error);
      alert(`Failed to save draft: ${error.message}`);
    }
  };

  const validateEquipmentDetails = (equipmentDetails) => {
    for (let equipment of equipmentDetails) {
      if (!equipment.make || !equipment.model || !equipment.serialNo || !equipment.yom) {
        return false;
      }
    }
    return true;
  };

  const handleAddressNext = () => {
    // const isValid = validatePopupFields();
    const isValid = true;
    setNonIndustrial(false);
    let sectionCovers = {};
    
    if(addressFormStep === 0) {
      if (!validateRiskFactors()) {
        return;
      }
      if (popupFormData['Equipment Type'] && !validateEquipmentDetails(popupFormData['Equipment Details'])) {
        alert("Please fill in all equipment details before proceeding.");
        return;
      }
    }

    if (addressFormStep === 2 || addressFormStep === 1) {
      isSubmit = true;
      if (!validateSectionSumInsured()) {
        return;
      }
  
      // Get all sections that should have covers
      const allSections = isEditing || isMultiEquipment ? productpackages : selectedPackages;
      
      // Initialize section covers for each section
      allSections.forEach(sectionName => {
        const name = isMultiEquipment ? sectionName.split('-').pop() : sectionName;
        const section = sections.find(section => section.section_reference_name === name);
        const sectionCode  =  isMultiEquipment ? sectionName.split('-')[0] : popupFormData["Equipment Type"]?.split("-")[0];
        sectionCovers[sectionName] = [];
  
        if (section) {
          const selectedOccupancy = occupancyData.find(
            occupancy => occupancy.code == popupFormData["Occupancy Type"]?.split('-')[0]
          );

          const selectedEquipment = equipmentData.find(
            (Equipment) => Equipment.code == sectionCode
          );
  
          // Get all covers for the section
          const allCovers = section.covers.split(', ');
          
          // Process each cover
          allCovers.forEach(cover => {
            let rate = '0';
            const coverRateTypes = JSON.parse(section.cover_rate_types || '[]');
            const autoRateCover = coverRateTypes.find(rt => rt.cover === cover && rt.rateType === 'Auto');
  
            if (autoRateCover) {
              // Calculate auto rate
              const componentRates = autoRateCover.coverComponents.map(compCover => {
                if (compCover === 'Basic' || compCover === 'STFI Cover' || compCover === 'Earthquake' || compCover === 'Terrorism') {
                  switch (compCover) {
                    case 'Basic':
                      return selectedOccupancy?.IIB_basic || selectedEquipment?.basic ||0;
                    case 'STFI Cover':
                      return (
                        selectedOccupancy?.IIB_stfi ||
                        selectedEquipment?.stfi ||
                        0
                      );
                    case 'Earthquake':
                      const zone = popupFormData['Zone'] || 'I';
                      const zoneNumber = getZoneNumber(zone);
                      return (
                        selectedOccupancy?.[`IIB_eq${zoneNumber}`] ||
                        selectedEquipment?.[`eq${zoneNumber}`] ||
                        0
                      );
                    case 'Terrorism':
                      return (
                        selectedOccupancy?.IIB_terrorism ||
                        selectedEquipment?.terrorism ||
                        0
                      );
                    default:
                      return 0;
                  }
                } else {
                  return parseFloat(section.direct_rate.split(', ')
                    .find(rate => rate.startsWith(`${compCover}-`))?.split('-')[1] || 0);
                }
              });
              rate = componentRates.reduce((sum, rate) => sum + rate, 0).toString();
            } else {
              // Get manual rate
              if (section.rate_type === 'direct') {
                rate = section.direct_rate.split(', ')
                  .find(r => r.startsWith(`${cover}-`))?.split('-')[1] || '0';
              } else if (
                section.rate_type === "occupancy" ||
                section.rate_type === "equipments"
              ) {
                rate = getOccupancyRate(
                  cover,
                  selectedOccupancy ? selectedOccupancy : selectedEquipment,
                  section
                );
              }
            }

            const isActiveForComponent  = componentCovers[section.components.split(', ')[0]]?.includes(cover) || false;

            if(isActiveForComponent) {
              sectionCovers[sectionName].push({
                cover: cover,
                rate: rate,
                is_active: isActiveForComponent
              });
            }
          });
        }
      });
    }
   
    const newAddress = {
      addressLine1: popupFormData['Address Line 1'],
      areaVillage: popupFormData['Area / Village'],
      districtCity: popupFormData['District / City'],
      state: popupFormData['State'],
      equipmentTypes: popupFormData['Equipment Type'],
      equipmentDetails: popupFormData['Equipment Details'],
      pincode: popupFormData['Pincode'],
      typeOfConstruction: popupFormData['Type Of Construction'],
      occupancyType: popupFormData['Occupancy Type'],
      equipmentType: popupFormData['Equipment Type'],
      ageOfRiskInformation: popupFormData['Age of the Risk Information'],
      heightOfBuilding: popupFormData['Height of the Building (in meters)'],
      noOfFloors: popupFormData['No. of Floors'],
      locationAddress: selectedZone ? 'Anywhere in India' : '',
      selectedPackage: selectedPackage,
      selectedComponents: selectedComponents,
      componentCovers: componentCovers,
      packageComponentValues: packageComponentValues,
      updatedRates: updatedRates,
      packageSumInsured: packageSumInsured,
      policyPeriod: formData['Risk Start Date'],
      policyEndPeriod: formData['Risk End Date'],
      multiEquipment: isMultiEquipment,
      floater: isFloater,
      user: isEditing ? user : user.user,
      title: title,
      name: mainData.name,
      selectedpackages: isEditing || isMultiEquipment ? productpackages : selectedPackages,
      mobile: mainData.mobile,
      dateOfBirth: mainData.dateOfBirth,
      dateOfIncorporation: mainData.dateOfIncorporation,
      panNumber: mainData.panNumber,
      individualOrCorporate: mainData.individualOrCorporate,
      gender: mainData.maleOrFemale,
      isEdited: isEditing,
      editId: isEditing ? id : null,
      sectionCovers: sectionCovers,
      selectedNumber: popupFormData['SelectedNumber']
    };
  
    if (isValid) {
      if (addressFormStep < 2) {
        setAddressFormStep(addressFormStep + 1);
      } else {
        const sectionSumInsured = Object.entries(packageComponentValues[isMultiEquipment ? actualPackage : selectedPackage] || {})
          .filter(([key]) => !key.endsWith('_premium')&&!key.endsWith('_terror'))
          .reduce((total, [_, value]) => total + (Number(value) || 0), 0);
          const type = popupFormData["Occupancy Type"] || popupFormData['Equipment Type'];
        const { totalPremium, terrorismPremium } = calculatePremium(componentCovers, type);
        const updatedSectionData = {
          ...sectionData,
          [isMultiEquipment ? actualPackage : selectedPackage]: {
            ...sectionData[isMultiEquipment ? actualPackage : selectedPackage],
            sumInsured: sectionSumInsured,
            premium: totalPremium,
            terrorism: terrorismPremium,
            updatedRates: { ...updatedRates }
          }
        };
  
        const componentDetails = {};
        selectedComponents.forEach(component => {
          const sumInsured = packageComponentValues[isMultiEquipment ? actualPackage : selectedPackage]?.[component] || 0;
          const premium = packageComponentValues[isMultiEquipment ? actualPackage : selectedPackage]?.[`${component}_premium`] || 0;
          componentDetails[component] = { sumInsured, premium };
        });
  
        setSectionData(updatedSectionData);
        newAddress.totalSumInsured = Object.values(updatedSectionData).reduce((total, section) => total + (section.sumInsured || 0), 0);
        newAddress.premium = Object.values(updatedSectionData).reduce((total, section) => total + (section.premium || 0), 0);
        newAddress.sections = updatedSectionData;
        newAddress.componentDetails = componentDetails;

  
        if (isEditMode) {
          setSubmittedAddresses((prevAddresses) => {
            const updatedAddresses = [...prevAddresses];
            updatedAddresses[editIndex] = newAddress;
            return updatedAddresses;
          });
        } else {
          setSubmittedAddresses((prevAddresses) => [...prevAddresses, newAddress]);
        }
        setShowAddressForm(false);
        setIsEditMode(false);
        setEditIndex(null);
      }
    } else {
      alert(errors.map(error => `• ${error}`).join('\n'));
    }
  };

  const handleAddComponents = () => {
    setShowComponentPopup(true);
  };

  const getSectionDisplayName = (pkg) => {
    const section = sections.find(section => 
      section.section_reference_name === pkg
    );
    return section ? section.section_name : pkg;
  };

  const handleClosePopup = () => {
    setShowComponentPopup(false);
  };

  const handleSaveComponents = () => {
    setShowComponentPopup(false);
  };

  const handleAddressPrevious = () => {
    setNonIndustrial(false);
    if (addressFormStep > 0) {
      if (addressFormStep === 2) {
        const currentSumInsured = Object.entries(packageComponentValues[isMultiEquipment ? actualPackage : selectedPackage] || {})
          .filter(([key]) => !key.endsWith('_premium')&&!key.endsWith('_terror'))
          .reduce((total, [_, value]) => total + (Number(value) || 0), 0);
          const type = popupFormData["Occupancy Type"] || popupFormData['Equipment Type'];
        const { totalPremium, terrorismPremium } = calculatePremium(componentCovers, type);
  
        // Get previous section values from sectionData
        const previousSectionData = sectionData[isMultiEquipment ? actualPackage : selectedPackage] || {};
        const previousSumInsured = previousSectionData.sumInsured || 0;
        const previousPremium = previousSectionData.premium || 0;
  
        // Only update if values have changed
        if (currentSumInsured !== previousSumInsured) {
          setUpdateSI(prevUpdateSI => prevUpdateSI + currentSumInsured - previousSumInsured);
        }

  
        if (totalPremium !== previousPremium) {
          setUpdatePre(prevUpdatePre => prevUpdatePre + totalPremium - previousPremium);
        }

        const currentRates = {};
        const section = sections.find(section => section.section_reference_name === selectedPackage);
          
        if (section) {
          section.covers.split(', ').forEach(cover => {
            const coverRateTypes = JSON.parse(section.cover_rate_types || '[]');
            const autoRateCover = coverRateTypes.find(rt => rt.cover === cover && rt.rateType === 'Auto');
            
            if (autoRateCover) {
              // Calculate auto rate
              const type = popupFormData["Occupancy Type"] || popupFormData['Equipment Type'];
              const seldectedOccupancy = occupancyData.find(
                occupancy => occupancy.code == type?.split('-')[0]
              );
              
              const componentRates = autoRateCover.coverComponents.map(compCover => {
                // ... existing auto rate calculation ...
              });
              const autoRate = componentRates.reduce((sum, rate) => sum + rate, 0).toString();
              currentRates[`${isMultiEquipment ? actualPackage : selectedPackage}-${cover}`] = autoRate;
            } else {
              // Save manual rates
              Object.keys(componentCovers).forEach(component => {
                if (componentCovers[component]?.includes(cover)) {
                  const rateKey = `${component}-${cover}`;
                  currentRates[rateKey] = updatedRates[rateKey] || '0';
                }
              });
            }
          });
        }

        setSectionData(prevData => ({
          ...prevData,
          [isMultiEquipment ? actualPackage : selectedPackage]: {
            ...prevData[isMultiEquipment ? actualPackage : selectedPackage],
            rates: currentRates
          }
        }));
        // Store current values in sectionData for future comparison
        setSectionData(prevData => ({
          ...prevData,
          [isMultiEquipment ? actualPackage : selectedPackage]: {
            ...prevData[isMultiEquipment ? actualPackage : selectedPackage],
            sumInsured: currentSumInsured,
            premium: totalPremium,
            terrorism: terrorismPremium,
            updatedRates: { ...updatedRates } // Store the updated rates
          }
        }));
      }
      if(validateSectionSumInsured() && addressFormStep === 2){
        setAddressFormStep(addressFormStep - 1);
      }
      else if(addressFormStep !== 2){
        setAddressFormStep(addressFormStep - 1);
      }
    }
  };

  const handleSubmit = () => {
    let updatedAddresses = submittedAddresses.map(address => {
      if (!address) return null;
      
      let addressTotalPremium = 0;
      
      if (address.sectionCovers && typeof address.sectionCovers === 'object') {
        Object.entries(address.sectionCovers).forEach(([sectionName, covers]) => {
          if (!covers || !Array.isArray(covers)) return;
          
          let sectionPremium = 0;
          const sectionSumInsured = address.packageComponentValues?.[sectionName] || {};
          
          covers.forEach(coverData => {
            const coverRate = parseFloat(coverData.rate || 0);
            const sumInsured = Object.keys(sectionSumInsured)
              .filter(key => !key.endsWith('_premium')&&!key.endsWith('_terror'))
              .reduce((total, key) => total + parseFloat(sectionSumInsured[key] || 0), 0);
            
            sectionPremium += (sumInsured * coverRate) / 1000;
          });
          
          // Apply policy risk factors for this specific section
          const finalSectionPremium = calculatePolicyRiskFactors(sectionPremium, sectionName, address);
          
          // Update section premium
          if (!address.sections) address.sections = {};
          address.sections[sectionName] = {
            ...(address.sections[sectionName] || {}),
            premium: finalSectionPremium
          };
          
          addressTotalPremium += finalSectionPremium;
        });
      }
      
      return {
        ...address,
        premium: addressTotalPremium
      };
    }).filter(Boolean);
    
    // The rest of your function remains the same
    let riskFactors = 0;
    Object.keys(popupFormData)
      .filter(key => key.startsWith('loadingDiscount_'))
      .forEach(key => {
        riskFactors = popupFormData[key]
      });
    
    updatedAddresses.riskFactors = riskFactors;
    updatedAddresses.riskExpand = isRiskFactorExpanded;
    updatedAddresses.projectNature = popupFormData['natureOfProject'];
    updatedAddresses.natureOfClaim = popupFormData['natureOfClaim'];
    updatedAddresses.yearOfClaim = popupFormData['yearOfClaim'];
    updatedAddresses.valueOfClaim = popupFormData['valueOfClaim'];
    updatedAddresses.postMeasures = popupFormData['postMeasures'];
    updatedAddresses.claimExperience = popupFormData['claimExperience'];
    updatedAddresses.hypothecation = popupFormData['hypothecation'];
    updatedAddresses.supportingDocuments = popupFormData['supportingDocuments'];
    updatedAddresses.supportingDocumentsURL = popupFormData['supportingDocumentsURL'];
    
    setSubmittedAddresses(updatedAddresses);
    navigate('/final-page', {
      state: {
        item: updatedAddresses,
        title: title,
        currentStep: currentStep
      }
    });
  };
  
  const renderRiskAddress = () => {

    const locationRiskFactors = riskFactor.filter(factor => {
      const requiredSections = isEditing || isMultiEquipment ? productpackages : selectedPackages;
      return factor.factor_type === 'Location' && 
             factor.section_name.split(', ').some(section => 
               requiredSections.includes(section)
             );
    });

    return (
      <>
        <div className="general-section">
          <h3>Risk Address</h3>
          {renderAddressPopupHeader()}              
        </div>
        {parsedWorkflows[1]?.sections?.map((section) => (
          <div key={section.name} className="general-section">
            <h3>{section.name}</h3>
            <div className="general-form-group-wrapper">
              {section.fields.map((field) => renderField(field, section.name, true))}
            </div>
          </div>
        ))}
        {locationRiskFactors.length > 0 && (
          <div className="general-section">
            <h3>
              Risk Factor Details
            </h3>
            <div className="general-form-group-wrapper">
              {riskFactor
                .filter(factor => {
                  const requiredSections = isEditing || isMultiEquipment ? productpackages : selectedPackages;
                  return factor.section_name.split(', ').some(section => 
                    requiredSections.includes(section)
                  );
                })
                .map((factor, index) => (
                  <div key={index} className="risk-factor-group">
                    {factor.type !== 'Free Entry' && factor.type !== 'Zone' && (
                      <div className="risk-factor-name">{factor.risk_factor_name}
                        {factor.list && factor.type !== 'Free Entry' && factor.type !== 'Zone' && (
                          <select 
                            className="risk-factor-list-select"
                            value={popupFormData[`riskFactorList_${factor.risk_factor_id}`] || ''}
                            onChange={(e) => {
                              const selectedValue = e.target.value;
                              if (factor.type === 'Direct' && selectedValue) {
                                const listValues = JSON.parse(factor.list_values);
                                const minValue = listValues[selectedValue]?.min || '';
                                
                                setPopupFormData(prev => ({
                                  ...prev,
                                  [`riskFactorList_${factor.risk_factor_id}`]: selectedValue,
                                  [`loadingDiscount_${factor.risk_factor_id}`]: minValue
                                }));
                              } else {
                                setPopupFormData(prev => ({
                                  ...prev,
                                  [`riskFactorList_${factor.risk_factor_id}`]: selectedValue
                                }));
                              }
                            }}
                          >
                            <option value="">Select {factor.risk_factor_name}</option>
                            {factor.list.split(', ').map((item, index) => (
                              <option key={index} value={item}>
                                {item}
                              </option>
                            ))}
                          </select>
                        )}
                      </div>
                    )}
                    {factor.type === 'Limit' && (
                      <div className="general-form-group">
                        <label>Loading/Discount (%)</label>
                        <input
                          type="number"
                          value={popupFormData[`loadingDiscount_${factor.risk_factor_id}`] ?? ''}
                          onChange={(e) => {
                            const value = e.target.value;
                            setPopupFormData(prev => ({
                              ...prev,
                              [`loadingDiscount_${factor.risk_factor_id}`]: value
                            }));
                          }}
                          onBlur={(e) => {
                            const value = e.target.value;
                            if (value === '') return;
              
                            const selectedOption = popupFormData[`riskFactorList_${factor.risk_factor_id}`];
                            if (!selectedOption) {
                              alert('Please select an option first');
                              setPopupFormData(prev => ({
                                ...prev,
                                [`loadingDiscount_${factor.risk_factor_id}`]: ''
                              }));
                              return;
                            }
              
                            const listValues = JSON.parse(factor.list_values);
                            const optionValues = listValues[selectedOption];
                            const numValue = parseFloat(value);
              
                            switch(factor.type) { 
                              case 'Limit':
                                const minLimit = parseFloat(optionValues.min);
                                const maxLimit = parseFloat(optionValues.max);
                                if (numValue < minLimit || numValue > maxLimit) {
                                  alert(`Value must be between ${minLimit}% and ${maxLimit}% for ${selectedOption}`);
                                  setPopupFormData(prev => ({
                                    ...prev,
                                    [`loadingDiscount_${factor.risk_factor_id}`]: minLimit.toString()
                                  }));
                                }
                                break;
                            }
                          }}
                          placeholder="Enter percentage"
                          disabled={!popupFormData[`riskFactorList_${factor.risk_factor_id}`]}
                        />
                      </div>
                    )}
                    {factor.type === 'Zone' && (
                      <div className="general-form-group">
                        <div className="risk-factor-name">{factor.risk_factor_name}</div>
                        {(() => {
                          const currentZone = isCopyAddressChecked ? formData['Zone'] : popupFormData['Zone'];
                          let zoneNumber;
                          switch(currentZone) {
                            case 'I':
                              zoneNumber = 'zone1';
                              break;
                            case 'II':
                              zoneNumber = 'zone2';
                              break;
                            case 'III':
                              zoneNumber = 'zone3';
                              break;
                            case 'IV':
                              zoneNumber = 'zone4';
                              break;
                            default:
                              zoneNumber = 'zone1';
                          }
                          return (
                            <div className="zone-value">
                              Zone {currentZone}
                            </div>
                          );
                        })()}
                      </div>
                    )}
                    {factor.type === 'Free Entry' && (
                      <div className="general-form-group">
                        <label>{factor.risk_factor_name} Loading/Discount (%)</label>
                        <input
                          type="number"
                          value={popupFormData[`loadingDiscount_${factor.risk_factor_id}`] ?? ''}
                          onChange={(e) => {
                            const value = e.target.value;
                            setPopupFormData(prev => ({
                              ...prev,
                              [`loadingDiscount_${factor.risk_factor_id}`]: value
                            }));
                          }}
                          onBlur={(e) => {
                            const value = e.target.value;
                            if (value === '') return;
                            const numValue = parseFloat(value);
                            const minLimit = parseFloat(factor.min);
                            const maxLimit = parseFloat(factor.max);
                            if (numValue < minLimit || numValue > maxLimit) {
                              alert(`Value must be between ${minLimit}% and ${maxLimit}%`);
                              setPopupFormData(prev => ({
                                ...prev,
                                [`loadingDiscount_${factor.risk_factor_id}`]: minLimit.toString()
                              }));
                            }
                          }}
                          placeholder="Enter percentage"
                        />
                      </div>
                    )}
                  </div>
                ))
              }
            </div>
          </div>
        )}
      </>
    );
  };

  const handleZoneChange = (zone) => {
    if(!isCopyAddressChecked){
      setSelectedZone(zone === selectedZone ? null : zone);
    }
    else{
      alert("cannot select both Copy address and Any Where In India")
    }
    
  };

  const renderAddressPopupHeader = () => {
    return (
      <>
        <div className="general-form-group half-width">
          <label htmlFor="copyAddress">Copy Address</label>
          <input
            type="checkbox"
            id="copyAddress"
            name="copyAddress"
            checked={isCopyAddressChecked}
            onChange={handleCopyAddressChange}
          />
        </div>
        {title === 'CPM' && (
          <div className='general-form-group-wrapper'>
            <div className="general-form-group">
              <label htmlFor="zoneI">Anywhere in India Zone I</label>
              <input
                type="checkbox"
                id="zoneI"
                name="zoneSelection"
                checked={selectedZone === 'I'}
                onChange={() => handleZoneChange('I')}
              />
            </div>
            <div className="general-form-group">
              <label htmlFor="zoneII">Anywhere in India Zone II</label>
              <input
                type="checkbox"
                id="zoneII"
                name="zoneSelection"
                checked={selectedZone === 'II'}
                onChange={() => handleZoneChange('II')}
              />
            </div>
            <div className="general-form-group">
              <label htmlFor="zoneIII">Anywhere in India Zone III</label>
              <input
                type="checkbox"
                id="zoneIII"
                name="zoneSelection"
                checked={selectedZone === 'III'}
                onChange={() => handleZoneChange('III')}
              />
            </div>
            <div className="general-form-group">
              <label htmlFor="zoneIV">Anywhere in India Zone IV</label>
              <input
                type="checkbox"
                id="zoneIV"
                name="zoneSelection"
                checked={selectedZone === 'IV'}
                onChange={() => handleZoneChange('IV')}
              />
            </div>
          </div>
        )}
      </>
    );
  };

  const renderCoverCard = (cover, index) => {
    const section = sections.find((section) => section.section_reference_name === selectedPackage);
    const isMandatory = section.mandatory_cover.split(', ').includes(cover);
    const isEnterableRate = section.enterable_rate.split(', ').includes(cover);
    const isActive = activeCovers[selectedPackage]?.[cover] !== "inactive";
    
    const isChecked = isMandatory || isActive;
    let rate = '0';
    let minRate = '0';

    const coverRateTypes = JSON.parse(section.cover_rate_types || '[]');
    const autoRateCover = coverRateTypes.find(rt => rt.cover === cover && rt.rateType === 'Auto');
    if (autoRateCover) {
      // Calculate sum of component rates
      const componentRates = autoRateCover.coverComponents.map(compCover => {
        const selectedOccupancy = occupancyData.find(
          occupancy => occupancy.code == popupFormData["Occupancy Type"]?.split('-')[0]
        );
        const selectedEquipment = equipmentData.find(
          equipment => equipment.code == popupFormData['Equipment Type']?.split('-')[0]
        );

        if (compCover === 'Basic' || compCover === 'STFI Cover' || compCover === 'Earthquake' || compCover === 'Terrorism') {
          switch (compCover) {
            case 'Basic':
              return (
                selectedOccupancy?.IIB_basic || selectedEquipment?.basic || 0
              );
            case 'STFI Cover':
              return (
                selectedOccupancy?.IIB_stfi || selectedEquipment?.stfi || 0
              );

            case 'Earthquake':
              const zone = popupFormData['Zone'] || 'I';
              const zoneNumber = getZoneNumber(zone);
              return (
                selectedOccupancy?.[`IIB_eq${zoneNumber}`] ||
                selectedEquipment?.[`eq${zoneNumber}`] ||
                0
              );
            case 'Terrorism':
              return (
                selectedOccupancy.IIB_terrorism ||
                selectedEquipment?.terrorism ||
                0
              );
            default:
              return 0;
          }
        }
        else {
          return section.direct_rate.split(', ')
            .find(rate => rate.startsWith(`${compCover}-`))?.split('-')[1] || 0;
        }
      });
  
      // Sum up all component rates
      rate = componentRates.reduce((sum, rate) => sum + parseFloat(rate), 0).toString();
    } else {
      if (section.rate_type === 'direct') {
        rate = section.direct_rate.split(', ').find((rate) => rate.startsWith(`${cover}-`))?.split('-')[1] || '0';
        minRate = section.direct_min_rate.split(', ').find((rate) => rate.startsWith(`${cover}-`))?.split('-')[1] || '0';
      } else if (section.rate_type === "occupancy" || section.rate_type === "equipments") {
        const type = popupFormData["Occupancy Type"] 
          ? popupFormData["Occupancy Type"] 
          : (isMultiEquipment 
          ? actualPackage.split(`-${selectedPackage}`)[0] 
          : popupFormData["Equipment Type"]);

        if (Array.isArray(type)) {
          setPopupFormData(prevData => ({
            ...prevData,
            "Equipment Type": type[0].label.split('-')[0]
          }));
        }
        
        let selectedOccupancy = null;
        let selectedEquipment = null;
        if(popupFormData["Occupancy Type"]) {
          selectedOccupancy = occupancyData.find(
            (occupancy) => occupancy.code == type.split("-")[0]
          );
        }
        else {
          selectedEquipment = equipmentData.find(
            (equipment) => equipment.code == type.split("-")[0]
          );
        }
        
        const occupancySectionRate = section.occupancy_rate.split(", ");
        const occupancyMinSectionRate = section.occupancy_min_rate.split(", ");
        if (selectedOccupancy || selectedEquipment) {
          switch (cover) {
            case "Basic":
              rate =
                selectedOccupancy? selectedOccupancy[occupancySectionRate[0]] : selectedEquipment[occupancySectionRate[0]]
                 ||
                "0";
              minRate = selectedOccupancy
                ? selectedOccupancy[occupancyMinSectionRate[0]]
                : "0";
              break;
            case "STFI Cover":
              rate =
                selectedOccupancy?selectedOccupancy[occupancySectionRate[1]] :  selectedEquipment[occupancySectionRate[1]]
                 ||
                "0";
              minRate = selectedOccupancy?selectedOccupancy[occupancyMinSectionRate[1]] : "0";
              break;
            case "Earthquake":
              const zone = popupFormData['Zone'] || 'I';
              let index;
              if(zone === 'II'){
                index = 3;
              }
              else if(zone === 'III'){
                index = 4;
              }
              else if(zone === 'IV'){
                index = 5;
              }
              else {
                index = 2
              }
              rate =
                selectedOccupancy?selectedOccupancy[occupancySectionRate[index]] : selectedEquipment[occupancySectionRate[index]]                 ||
                "0";
              minRate = selectedOccupancy?selectedOccupancy[occupancyMinSectionRate[2]] : "0";
              break;
            case "Terrorism":
              rate =
                selectedOccupancy?selectedOccupancy[occupancySectionRate[6]] : selectedEquipment[occupancySectionRate[6]]
                 ||
                "0";
              minRate = selectedOccupancy?selectedOccupancy[occupancyMinSectionRate[6]] : "0";
              break;
            default:
              rate = "0";
              minRate = "0";
          }
        }
      }
    }
  
    return (
      <div key={index} className="cover-card">
        <div className="cover-content">
          <div className='cover-wrapper'>
            <input
              type='checkbox'
              defaultChecked={isChecked}
              disabled={isMandatory}
              onChange={(e) => {
                e.preventDefault();
                if (Object.entries(packageComponentValues).length > 0) {
                  handleCoverChange(focusedComponent, cover, e.target.checked)
                } else {
                  alert("Please enter SI first");
                }
              }}
            />
            <h3>{cover}</h3>
          </div>
          <div className="component-details">
            <div className='rate-values'>
              Rate: {isEnterableRate ? (
                <input
                  type="number"
                  step="0.0001"
                  value={updatedRates[`${focusedComponent}-${cover}`] || rate}
                  onChange={(e) => {
                    const newValue = e.target.value;
                    // Validate to ensure max 4 decimal places
                    const regex = /^\d*\.?\d{0,4}$/;
                    if (regex.test(newValue) || newValue === '') {
                      setUpdatedRates((prevRates) => ({
                        ...prevRates,
                        [`${focusedComponent}-${cover}`]: newValue,
                      }));
                    }
                  }}
                  onBlur={(e) => {
                    const newRate = e.target.value;
                    // First check for minimum rate
                    if (newRate < minRate) {
                      alert(`The rate for ${cover} cannot be below the minimum rate of ${minRate}.`);
                      setUpdatedRates((prevRates) => ({
                        ...prevRates,
                        [`${focusedComponent}-${cover}`]: minRate,
                      }));
                    }
                    // Then format to ensure no more than 4 decimal places
                    const formattedValue = Number(newRate).toFixed(4).replace(/\.?0+$/, '');
                    setUpdatedRates((prevRates) => ({
                      ...prevRates,
                      [`${focusedComponent}-${cover}`]: formattedValue,
                    }));
                  }}
                />
              ) : (
                Number(rate).toFixed(4).replace(/\.?0+$/, '')
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };


  const handleSelectChange = (e) => {
    const option = e.target.value;
    setPopupFormData(prev => ({
      ...prev,
      'SelectedNumber': option
    }));
  };

  const renderField = (field, sectionName, isPopup = false) => {
    const data = isPopup ? popupFormData : formData;
    const handleChangeFn = isPopup ? handlePopupChange : handleChange;

    if(title !== 'IAR') {
      if (sectionName === 'Customer Details' && field.dependsOn && formData['Is Customer Individual or Corporate'] !== field.dependsOn) {
        return null;
      }
    }
    if(title === 'IAR') {
      if(sectionName === 'Customer Details' && field.label === 'Gender') {
        return null;
      }
    }

    if((sectionName === 'Claim Experience in last 3 years' || sectionName === 'Claim Experience in last 5 years') && field.label !== "Has Claims"){
      if(formData['Has Claims']===false){
        return null
      }
    }

    if(sectionName === 'Financier Details'){
      return null;
    }

    if(sectionName === 'Co-Insurance Details'){
      return null;
    }
  
    const formGroupClass = `general-form-group ${field.label === 'Is Customer Individual or Corporate' || field.label === 'Corporate Customer' || field.type === 'checkbox' ? 'half-width' : ''}`;
    switch (field.type) {
      case 'text':
      case 'date':
      case 'number':
        return (
          <div className={formGroupClass} key={field.label}>
            <label htmlFor={field.label}>{field.label}</label>
            <input
              type={field.type === 'date' ? 'date' : field.type}
              id={field.label}
              name={field.label}
              value={data[field.label] || ''}
              onChange={handleChangeFn}
              required={field.required}
              onFocus={field.type === 'date' ? (e) => e.target.showPicker() : undefined}
              disabled={field.editable === false || field.label === 'Risk End Date'}
              max={field.label === 'Date of Birth' ? getMaxDateOfBirth() : field.label === 'Risk Start Date' ? getMaxRiskStartDate() : undefined}
              min={field.label === 'Risk Start Date' ? getMinRiskStartDate() : undefined}
            />
          </div>
        );
        case 'dropdown':
          return (
            <div className={formGroupClass} key={field.label}>
              <label htmlFor={field.label}>{field.label}</label>
              {field.label === 'Equipment Type' ? (
                <>
                  <Select
                    isMulti={isMultiEquipment}
                    options={equipmentOptions.map((label) => ({ label, value: label.toLowerCase() }))}
                    onChange={(selectedOption) => {
                      if (isMultiEquipment) {
                        handleEquipmentChange(selectedOption);
                      } else {
                        const singleOptionAsArray = selectedOption ? [selectedOption] : [];
                        handleEquipmentChange(singleOptionAsArray);
                        handleChangeFn({ target: { name: field.label, value: selectedOption.value } });
                      }
                    }}
                    value={
                      isMultiEquipment 
                        ? popupFormData['Equipment Type'] || []
                        : equipmentOptions.map((label) => ({ label, value: label.toLowerCase() }))
                            .find(option => {
                              const currentValue = data[field.label];
                              if (Array.isArray(currentValue)) {
                                return currentValue.length > 0 ? 
                                  option.value === currentValue[0].value : false;
                              }
                              return option.value === currentValue?.toLowerCase();
                            })
                    }
                  />
                  {/* Always show equipment details table if there are equipment details */}
                  {popupFormData['Equipment Details'] && popupFormData['Equipment Details'].length > 0 && (
                    <div className="equipment-details-table">
                      <table>
                        <thead>
                          <tr>
                            <th>Equipment</th>
                            <th>Make</th>
                            <th>Model</th>
                            <th>Serial No</th>
                            <th>YOM</th>
                          </tr>
                        </thead>
                        <tbody>
                          {popupFormData['Equipment Details'].map((equipment, index) => (
                            <tr key={index}>
                              <td>{equipment.equipment}</td>
                              <td>
                                <input
                                  type="text"
                                  value={equipment.make || ''}
                                  onChange={(e) => handleEquipmentDetailChange(index, 'make', e.target.value)}
                                />
                              </td>
                              <td>
                                <input
                                  type="text"
                                  value={equipment.model || ''}
                                  onChange={(e) => handleEquipmentDetailChange(index, 'model', e.target.value)}
                                />
                              </td>
                              <td>
                                <input
                                  type="text"
                                  value={equipment.serialNo || ''}
                                  onChange={(e) => handleEquipmentDetailChange(index, 'serialNo', e.target.value)}
                                />
                              </td>
                              <td>
                                <input
                                  type="text"
                                  value={equipment.yom || ''}
                                  onChange={(e) => {
                                    const value = e.target.value;
                                    if (validateYOM(value)) {
                                      handleEquipmentDetailChange(index, 'yom', value);
                                    }
                                  }}
                                  maxLength={4}
                                />
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              ) : field.label === 'Occupancy Type' ? (
                <Select
                  isMulti={false}
                  options={occupancyOptions.map((label) => ({ label, value: label.toLowerCase() }))}
                  onChange={(selectedOption) => handleChangeFn({ target: { name: field.label, value: selectedOption.value } })}
                  value={
                    occupancyOptions.map((label) => ({ label, value: label.toLowerCase() }))
                      .find(option => option.value === data[field.label]?.toLowerCase())
                  }
                />
              ) : (
                <select
                  id={field.label}
                  name={field.label}
                  value={data[field.label] || ''}
                  onChange={handleChangeFn}
                  required={field.required}
                >
                  <option value="">Select {field.label}</option>
                  {field.label === 'Area / Village' ? (
                    areaOptions.map((option, index) => (
                      <option key={index} value={option}>
                        {option}
                      </option>
                    ))
                  ) : field.options ? (field.options.map((option, index) => (
                      <option key={index} value={option}>
                        {option}
                      </option>
                    ))): ('')
                  }
                </select>
              )}
            </div>
          );        
      case 'toggle':
        return (
          <div className={formGroupClass} key={field.label}>
            <label>{field.label}</label>
            <div className="general-toggle-buttons">
              {field.options.map((option) => (
                <button
                  type="button"
                  key={option}
                  className={`general-toggle-button ${data[field.label] === option ? 'active' : ''}`}
                  onClick={() => handleChangeFn({ target: { name: field.label, value: option } })}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        );
      case 'checkbox':
        return (
          <div className={formGroupClass} key={field.label}>
            <label htmlFor={field.label}>{field.label}</label>
            <input
              type="checkbox"
              id={field.label}
              name={field.label}
              defaultChecked={field.label === "Multi Equipment" ? isMultiEquipment ? true : data[field.label] || false : data[field.label] || false}
              onChange={handleChangeFn}
            />
          </div>
        );
      case 'search':
        return (
          <div className={formGroupClass} key={field.label}>
            <label htmlFor={field.label}>{field.label}</label>
            <input
              type="text"
              id={field.label}
              name={field.label}
              value={data[field.label] || ''}
              onChange={handleChangeFn}
              required={field.required}
            />
            {/* Implement search dropdown logic here */}
          </div>
        );
      case 'button':
        return (
          <div className={formGroupClass} key={field.label}>
            <button className="general-popup-button" type="button" onClick={handleAddAddressClick}>
              {field.label}
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  const RenderRiskFactor = () => {
    const policyRiskFactors = riskFactor.filter(factor => {
      const requiredSections = isEditing ? isMultiEquipment ? selectedPackages : productpackages : selectedPackages;
      return factor.factor_type === 'Policy' && 
             factor.section_name.split(', ').some(section => 
               requiredSections.includes(section)
             );
    });
    return (
      <>
      <div className="general-section">
        <h3 className='other-section'>Other Details</h3>
        <h3 
          onClick={() => setIsRiskFactorExpanded(!isRiskFactorExpanded)}
          className="expandable-header"
        >
          <span>{title === 'IAR' ? 'Claims Experience Details' :'Risk Factor Details'}</span>
        </h3>
        {policyRiskFactors.length > 0 && (
          <div className="general-form-group-wrapper">
          {riskFactor
            .filter(factor => {
              const requiredSections = isEditing ? isMultiEquipment ? selectedPackages : productpackages : selectedPackages;
              return factor.section_name.split(', ').some(section => 
                requiredSections.includes(section)
              );
            })
            .map((factor, index) => (
              <div key={index} className="risk-factor-group">
                {factor.type !== 'Free Entry' && factor.type !== 'Zone' && (
                  <div className="risk-factor-name">{factor.risk_factor_name}
                    {factor.list && factor.type !== 'Free Entry' && factor.type !== 'Zone' && (
                      <select 
                        className="risk-factor-list-select"
                        value={popupFormData[`riskFactorList_${factor.risk_factor_id}`] || ''}
                        onChange={(e) => {
                          const selectedValue = e.target.value;
                          if (factor.type === 'Direct' && selectedValue) {
                            const listValues = JSON.parse(factor.list_values);
                            const minValue = listValues[selectedValue]?.min || '';
                            
                            setPopupFormData(prev => ({
                              ...prev,
                              [`riskFactorList_${factor.risk_factor_id}`]: selectedValue,
                              [`loadingDiscount_${factor.risk_factor_id}`]: minValue
                            }));
                          } else {
                            setPopupFormData(prev => ({
                              ...prev,
                              [`riskFactorList_${factor.risk_factor_id}`]: selectedValue
                            }));
                          }
                        }}
                      >
                        <option value="">Select {factor.risk_factor_name}</option>
                        {factor.list.split(', ').map((item, index) => (
                          <option key={index} value={item}>
                            {item}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                )}
                {factor.type === 'Limit' && (
                  <div className="general-form-group">
                    <label>Loading/Discount (%)</label>
                    <input
                      type="number"
                      value={popupFormData[`loadingDiscount_${factor.risk_factor_id}`] ?? ''}
                      onChange={(e) => {
                        const value = e.target.value;
                        setPopupFormData(prev => ({
                          ...prev,
                          [`loadingDiscount_${factor.risk_factor_id}`]: value
                        }));
                      }}
                      onBlur={(e) => {
                        const value = e.target.value;
                        if (value === '') return;
          
                        const selectedOption = popupFormData[`riskFactorList_${factor.risk_factor_id}`];
                        if (!selectedOption) {
                          alert('Please select an option first');
                          setPopupFormData(prev => ({
                            ...prev,
                            [`loadingDiscount_${factor.risk_factor_id}`]: ''
                          }));
                          return;
                        }
          
                        const listValues = JSON.parse(factor.list_values);
                        const optionValues = listValues[selectedOption];
                        const numValue = parseFloat(value);
          
                        switch(factor.type) { 
                          case 'Limit':
                            const minLimit = parseFloat(optionValues.min);
                            const maxLimit = parseFloat(optionValues.max);
                            if (numValue < minLimit || numValue > maxLimit) {
                              alert(`Value must be between ${minLimit}% and ${maxLimit}% for ${selectedOption}`);
                              setPopupFormData(prev => ({
                                ...prev,
                                [`loadingDiscount_${factor.risk_factor_id}`]: minLimit.toString()
                              }));
                            }
                            break;
                        }
                      }}
                      placeholder="Enter percentage"
                      disabled={!popupFormData[`riskFactorList_${factor.risk_factor_id}`]}
                    />
                  </div>
                )}
                {factor.type === 'Zone' && (
                  <div className="general-form-group">
                    <div className="risk-factor-name">{factor.risk_factor_name}</div>
                    {(() => {
                      const currentZone = isCopyAddressChecked ? formData['Zone'] : popupFormData['Zone'];
                      let zoneNumber;
                      switch(currentZone) {
                        case 'I':
                          zoneNumber = 'zone1';
                          break;
                        case 'II':
                          zoneNumber = 'zone2';
                          break;
                        case 'III':
                          zoneNumber = 'zone3';
                          break;
                        case 'IV':
                          zoneNumber = 'zone4';
                          break;
                        default:
                          zoneNumber = 'zone1';
                      }
                      return (
                        <div className="zone-value">
                          Zone {currentZone}
                        </div>
                      );
                    })()}
                  </div>
                )}
                {factor.type === 'Free Entry' && (
                  <div className="general-form-group">
                    <label>{factor.risk_factor_name} Loading/Discount (%) (use '-' for Discount)</label>
                    <input
                      type="number"
                      value={popupFormData[`loadingDiscount_${factor.risk_factor_id}`] ?? ''}
                      onChange={(e) => {
                        const value = e.target.value;
                        setPopupFormData(prev => ({
                          ...prev,
                          [`loadingDiscount_${factor.risk_factor_id}`]: value
                        }));
                      }}
                      onBlur={(e) => {
                        const value = e.target.value;
                        if (value === '') return;
                        const numValue = parseFloat(value);
                        const minLimit = parseFloat(factor.min);
                        const maxLimit = parseFloat(factor.max);
                        if (numValue < minLimit || numValue > maxLimit) {
                          alert(`Value must be between ${minLimit}% and ${maxLimit}%`);
                          setPopupFormData(prev => ({
                            ...prev,
                            [`loadingDiscount_${factor.risk_factor_id}`]: minLimit.toString()
                          }));
                        }
                      }}
                      placeholder="Enter percentage"
                    />
                  </div>
                )}
              </div>
            ))
          }
        </div>)}
      </div>
      {title === "CPM" && (
        <>
          <div className="general-form-group-wrapper">
            <div className="general-form-group">
              <label>Nature of Project</label>
              <input
                type="text"
                value={popupFormData['natureOfProject'] || ''}
                onChange={(e) => {
                  setPopupFormData(prev => ({
                    ...prev,
                    'natureOfProject': e.target.value
                  }));
                }}
                placeholder="Enter nature of project"
                rows={4}
              />
            </div>
          </div>
          <div className="general-form-group-wrapper">
            <div className="general-form-group">
              <label>Claim Experience in Last 5 years</label>
              <input
                type="number"
                value={popupFormData['claimExperience'] || ''}
                onChange={(e) => {
                  setPopupFormData(prev => ({
                    ...prev,
                    'claimExperience': e.target.value
                  }));
                }}
                placeholder="Enter number of claims"
                min="0"
              />
            </div>
          </div>
          <div className="general-form-group-wrapper">
            <div className="general-form-group">
              <label>Hypothecation/Financier (If any)</label>
              <input
                type="text"
                value={popupFormData['hypothecation'] || ''}
                onChange={(e) => {
                  setPopupFormData(prev => ({
                    ...prev,
                    'hypothecation': e.target.value
                  }));
                }}
                placeholder="Enter financier details"
              />
            </div>
          </div>
        </>
        )}
        {title === "IAR" && (
        <>
          <div className="general-form-group-wrapper">
            <div className="general-form-group">
              <label>RFQ & Asset List/Annexure</label>
              <div className="file-input-container">
                <input
                  type="file"
                  onChange={(e) => {
                    const file = e.target.files[0];
                    if (file) {
                      const validTypes = [
                        'application/pdf', 
                        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
                        'application/vnd.ms-excel',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'application/msword',
                        'image/jpeg',
                        'image/png',
                        'image/gif'
                      ];
                      if (validTypes.includes(file.type)) {
                        const fileURL = URL.createObjectURL(file);
                        setPopupFormData(prev => ({
                          ...prev,
                          'supportingDocuments': file,
                          'supportingDocumentsURL': fileURL
                        }));
                      } else {
                        alert('Please upload only Excel, PDF, Word documents, or images');
                        e.target.value = null;
                      }
                    }
                  }}
                  accept=".pdf,.xls,.xlsx,.doc,.docx,.jpg,.jpeg,.png,.gif"
                  id="fileInput"
                />
                <small>Allowed file types: PDF, Excel, Word, and Images</small>
                
                {popupFormData['supportingDocuments'] && (
                  <div className="selected-file">
                    <span>Selected file: {popupFormData['supportingDocuments'].name}</span>
                    <div className="file-actions">
                      <button 
                        type="button" 
                        className="view-file-btn"
                        onClick={() => {
                          if (popupFormData['supportingDocumentsURL']) {
                            window.open(popupFormData['supportingDocumentsURL'], '_blank');
                          }
                        }}
                      >
                        View
                      </button>
                      <button 
                        type="button" 
                        className="remove-file-btn"
                        onClick={() => {
                          if (popupFormData['supportingDocumentsURL']) {
                            URL.revokeObjectURL(popupFormData['supportingDocumentsURL']);
                          }
                          
                          setPopupFormData(prev => {
                            const newFormData = {...prev};
                            delete newFormData['supportingDocuments'];
                            delete newFormData['supportingDocumentsURL'];
                            return newFormData;
                          });
                          document.getElementById('fileInput').value = null;
                        }}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          <div className="general-form-group-wrapper">
            <div className="general-form-group">
              <label>Nature of Claim</label>
              <input
                type="text"
                value={popupFormData['natureOfClaim'] || ''}
                onChange={(e) => {
                  setPopupFormData(prev => ({
                    ...prev,
                    'natureOfClaim': e.target.value
                  }));
                }}
                placeholder="Enter nature of claim"
                rows={4}
              />
            </div>
          </div>
          <div className="general-form-group-wrapper">
            <div className="general-form-group">
              <label>Year of Claim</label>
              <input
                type="number"
                value={popupFormData['yearOfClaim'] || ''}
                onChange={(e) => {
                  setPopupFormData(prev => ({
                    ...prev,
                    'yearOfClaim': e.target.value
                  }));
                }}
                placeholder="Enter year of claims"
                min="0"
              />
            </div>
          </div>
          <div className="general-form-group-wrapper">
            <div className="general-form-group">
              <label>Value of Claim</label>
              <input
                type="number"
                value={popupFormData['valueOfClaim'] || ''}
                onChange={(e) => {
                  setPopupFormData(prev => ({
                    ...prev,
                    'valueOfClaim': e.target.value
                  }));
                }}
                placeholder="Enter value of claims"
                min="0"
              />
            </div>
          </div>
          <div className="general-form-group-wrapper">
            <div className="general-form-group">
              <label>Post Measures</label>
              <input
                type="text"
                value={popupFormData['postMeasures'] || ''}
                onChange={(e) => {
                  setPopupFormData(prev => ({
                    ...prev,
                    'postMeasures': e.target.value
                  }));
                }}
                placeholder="Enter Post measures"
              />
            </div>
          </div>
        </>
        )}
      </>
    )
  }

  return (
    <div className="general-details">
      {showAddressForm ? (
        <div>
          {addressFormStep === 0 && renderRiskAddress()}
          {addressFormStep === 1 && (
            <div className='general-package-grid'>
              {(isEditing || isMultiEquipment ? productpackages : selectedPackages).map((pkg, index) => {
                const sectionRules = maxSumInsuredRules[pkg];
                const referencedSectionSumInsured = sectionRules?.section ? 
                  packageSumInsured[sectionRules.section] || 0 : 0;
                const isAccessible = validateSectionAccess(pkg);

                return (
                  <div 
                    key={index} 
                    className={`package-card`}
                  >
                    <div className="package-content">
                      <div className='section-wrapper'>
                        <h3>{isMultiEquipment ? pkg : getSectionDisplayName(pkg)}</h3>
                      </div>
                      <div className="component-details">
                        <p>Sum Insured: {
                          new Intl.NumberFormat('en-IN').format(
                            (packageSumInsured && packageSumInsured[title === "SFSP" ? "SFSP-FIRE" : pkg]) || 0
                          )
                        }</p>
                      </div>
                    </div>
                    <div 
                      className="card-overlay"
                      onClick={() => {
                        if (sectionRules?.type === 'Section Based' && referencedSectionSumInsured <= 0) {
                          alert(`Please add sum insured for ${sectionRules.section} first`);
                          return;
                        }
                        if (!isAccessible && sectionRules?.sumInsuredPercentage) {
                          alert(`Sum insured cannot exceed ${sectionRules.sumInsuredPercentage}% of ${sectionRules.section}`);
                          return;
                        }
                        handlePackageClick(title === "SFSP" ? "SFSP-FIRE" : pkg);
                      }}
                    />
                  </div>
                );
              })}
            </div>
          )}
          {addressFormStep === 2 && (
            <div className="third-step-container">
              <div className="components-section">
                <div className='title'>Components</div>
                <div className='general-component-grid'>
                  {sections
                    .filter((section) => section.section_reference_name === selectedPackage)
                    .flatMap((section) => isFloater ? section.applied_floaters.split(', ') : section.components.split(', '))
                    .filter((component, index) => selectedComponents.includes(component) || index < 4)
                    .map((component, index) => (
                      <div key={index} className="component-card" onClick={() => setFocusedComponent(component)}>
                        <div className="component-content">
                          <div className='component-wrapper'>
                            <h3>{component}</h3>
                          </div>
                          <div className="component-details">
                            {maxSumInsuredRules[selectedPackage]?.type === 'Person Based' && (
                              <div className="person-count-input">
                                <label>No. of Persons:</label>
                                <input 
                                  type="number"
                                  min="1"
                                  value={maxSumInsuredRules[selectedPackage]?.componentData?.[component]?.numberOfPerson ?? ''}
                                  onChange={(e) => {
                                    const value = e.target.value === '' ? '' : Math.max(0, parseInt(e.target.value) || 0);
                                    setMaxSumInsuredRules(prev => ({
                                      ...prev,
                                      [selectedPackage]: {
                                        ...prev[selectedPackage],
                                        componentData: {
                                          ...prev[selectedPackage]?.componentData,
                                          [component]: {
                                            ...prev[selectedPackage]?.componentData?.[component],
                                            numberOfPerson: value === '' ? '' : parseInt(value),
                                            sumInsuredValue: prev[selectedPackage]?.componentData?.[component]?.sumInsuredValue || ''
                                          }
                                        }
                                      }
                                    }));
                                  }}
                                  onBlur={(e) => {
                                    if (e.target.value === '' || parseInt(e.target.value) < 1) {
                                      setMaxSumInsuredRules(prev => ({
                                        ...prev,
                                        [selectedPackage]: {
                                          ...prev[selectedPackage],
                                          componentData: {
                                            ...prev[selectedPackage]?.componentData,
                                            [component]: {
                                              ...prev[selectedPackage]?.componentData?.[component],
                                              numberOfPerson: 1
                                            }
                                          }
                                        }
                                      }));
                                    }
                                  }}
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>
                            )}
                            <input 
                              className='insure-amt' 
                              type='number'
                              onFocus={() => {
                                setFocusedComponent(component);
                              }}
                              onChange={(e) => {
                                const value = Math.min(999999999999, Math.max(0, Number(e.target.value)));
                                if (maxSumInsuredRules[selectedPackage]?.type === 'Person Based') {
                                  const componentRules = maxSumInsuredRules[selectedPackage]?.componentData?.[component];
                                  const numberOfPersons = componentRules?.numberOfPerson || 0;
                                  const sumInsuredPerPerson = componentRules?.sumInsuredValue || 0;
                                  const maxAllowed = numberOfPersons * sumInsuredPerPerson;
                                  
                                  if (value > maxAllowed) {
                                    alert(
                                      `For ${component}, sum insured cannot exceed ${maxAllowed} ` +
                                      `(${sumInsuredPerPerson} per person × ${numberOfPersons} persons)`
                                    );
                                    return;
                                  }
                                }
                                const equipment =  isMultiEquipment ? actualPackage : selectedPackage;

                                handleComponentValueChange(selectedPackage, component, value, equipment);
                              }}
                              value={
                                packageComponentValues[isMultiEquipment ? actualPackage : selectedPackage]?.[component] || 
                                (componentData[component]?.sumInsuredType === 'Auto' ? 
                                  calculateAutoSumInsured(component, selectedPackage) : '')
                              }
                            />
                          </div>
                          {title === 'IAR' && selectedPackage === "BUSINESS INTERRUPT" && (<span className="gen-dropdown-container">
                            <label htmlFor="numberSelect" className="dropdown-label">
                              Indemnity Period 
                            </label>
                            <select
                              id="numberSelect"
                              className="dropdown-select"
                              value={popupFormData['SelectedNumber'] || ''}
                              onChange={handleSelectChange}
                            >
                              <option value="">Select a number</option>
                              {Array.from({ length: 24 }, (_, i) => i + 1).map(num => (
                                <option key={num} value={num}>
                                  {num}
                                </option>
                              ))}
                            </select>
                          </span>)}
                        </div>
                      </div>
                    ))}
                </div>
                {sections
                  .filter((section) => section.section_reference_name === selectedPackage)
                  .flatMap((section) => isFloater ? section.applied_floaters.split(', ') : section.components.split(', ')).length > 4 && (
                    <button className="add-component-button" onClick={handleAddComponents}>Add</button>
                  )}
              </div>
              <div className="covers-section">
                <div className='title'>Covers</div>
                <div className='general-cover-grid'>
                {sections
                  .filter((section) => section.section_reference_name === selectedPackage)
                  .flatMap((section) => section.covers.split(', '))
                  .map((cover, index) => renderCoverCard(cover, index))}
                </div>
              </div>
            </div>
          )}
          {showComponentPopup && (
            <div className="component-popup">
              <div className="popup-content">
                <h3>Select Components</h3>
                <div className="component-list">
                  {sections
                    .filter((section) => section.section_reference_name === selectedPackage)
                    .flatMap((section) => section.components.split(', '))
                    .map((component, index) => (
                      <div key={index} className="component-item">
                        <input
                          type="checkbox"
                          defaultChecked={selectedComponents.includes(component) || index < 4}
                          onChange={() => handleComponentSelectionChange(component)}
                        />
                        <label>{component}</label>
                      </div>
                    ))}
                </div>
                <button className="save-button" onClick={handleSaveComponents}>Save</button>
                <button className="close-button" onClick={handleClosePopup}>Close</button>
              </div>
            </div>
          )}
          <div className="navigation-buttons">
            <div className="left-button">
              {addressFormStep > 0 ? <button className='general-previous-button' onClick={handleAddressPrevious}>Previous</button> : <button className='general-previous-button' type="button" onClick={() => setShowAddressForm(false)}>Back</button>}
            </div>
            <div className="center-button">
              <button className="save-draft-button" onClick={handleSaveDraft}>
                Save as Draft
              </button>
            </div>
            <div className="right-button">
            {addressFormStep !== 1 && (<button className='general-next-button' onClick={handleAddressNext}>Next</button>)}
            </div>
          </div>
        </div>
      ) : (
        <>
          {parsedWorkflows.length > 0 && (
            <>
              {workflow > 1 && (
                <div className="stepper">
                  {Array.from({ length: workflow }).map((_, index) => (
                    <div
                      key={index}
                      className={`step ${index === currentStep ? 'active' : ''}`}
                      onClick={() => handleStepClick(index)}
                    >
                      {index + 1}
                    </div>
                  ))}
                </div>
              )}
              {currentStep === 1 && (
                <div className="general-section">
                  <h3>Risk Address</h3>
                  <div className="general-form-group-wrapper">
                    <div className="general-form-group">
                      <button 
                        className="general-popup-button" 
                        type="button" 
                        onClick={handleAddAddressClick}
                      >
                        Add Address
                      </button>
                      <div className="address-summary">
                        {submittedAddresses.map((address, index) => (
                          <div key={index} className="address-summary-card">
                          <div className="summary-index">L{index + 1}</div>
                          <div className="summary-address">
                            <p>{address.districtCity}, {address.state}, {address.pincode}</p>
                            <div className="summary-details">
                              <p>Occupancy: {address.occupancyType}</p>
                            </div>
                          </div>
                          <div className="summary-financials">
                            <div className="summary-amount">
                              <span>Sum Insured</span>
                              <strong>₹{
                              new Intl.NumberFormat('en-IN').format(
                              address.totalSumInsured)}
                              </strong>
                            </div>
                          </div>
                          <div className="summary-actions">
                            <button 
                              className="edit-button"
                              onClick={() => handleEditAddressClick(index)}
                            >
                              Edit
                            </button>
                          </div>
                        </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {currentStep === 2 && (
                RenderRiskFactor()
              )}
              { currentStep === 0 && parsedWorkflows[0]?.sections?.map((section) => (
                <div key={section.name} className="general-section">
                  <h3>{section.name}</h3>
                  <div className="general-form-group-wrapper">
                    {section.fields.map((field) => renderField(field, section.name))}
                  </div>
                </div>
              ))}
              { currentStep === 0 && (() => {
                const parsedSegments = JSON.parse(userSegment);
                const segmentKeys = Object.keys(parsedSegments);
                
                // Hide the section if there's only one segment with one division
                if (segmentKeys.length === 1 && parsedSegments[segmentKeys[0]].length === 1) {
                  // Automatically set the values in formData
                  if (!formData['Segment'] || !formData['Division']) {
                    setFormData(prev => ({
                      ...prev,
                      'Segment': segmentKeys[0],
                      'Division': parsedSegments[segmentKeys[0]][0]
                    }));
                  }
                  return null;
                }

                return (
                  <>
                  <div key="financier-details" className="general-section">
                    <h3>Financier Details</h3>
                    <div className="general-form-group-wrapper">
                      <div className="general-form-group">
                        <div className="financier-checkbox-container">
                          <input
                            type="checkbox"
                            id="hasFinancier"
                            checked={formData['hasFinancier'] || false}
                            onChange={(e) => {
                              handleChange({
                                target: {
                                  name: 'hasFinancier',
                                  value: e.target.checked
                                }
                              });
                            }}
                            className="financier-checkbox"
                          />
                          <label htmlFor="hasFinancier">Has Financier</label>
                        </div>
                      </div>
                    </div>

                    {formData['hasFinancier'] && (
                      <div className="financier-table-container">
                        <table className="financier-table">
                          <thead>
                            <tr>
                              <th>Name</th>
                              <th>Branch Address</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(formData['financiers'] || [{ id: 1, name: '', branchAddress: '' }]).map((financier, index) => (
                              <tr key={financier.id || index}>
                                <td>
                                  <input
                                    type="text"
                                    value={financier.name || ''}
                                    onChange={(e) => {
                                      const updatedFinanciers = [...(formData['financiers'] || [{ id: 1, name: '', branchAddress: '' }])];
                                      updatedFinanciers[index] = {
                                        ...updatedFinanciers[index],
                                        name: e.target.value
                                      };
                                      handleChange({
                                        target: {
                                          name: 'financiers',
                                          value: updatedFinanciers
                                        }
                                      });
                                    }}
                                    className="financier-input"
                                    placeholder="Financier Name"
                                  />
                                </td>
                                <td>
                                  <input
                                    type="text"
                                    value={financier.branchAddress || ''}
                                    onChange={(e) => {
                                      const updatedFinanciers = [...(formData['financiers'] || [{ id: 1, name: '', branchAddress: '' }])];
                                      updatedFinanciers[index] = {
                                        ...updatedFinanciers[index],
                                        branchAddress: e.target.value
                                      };
                                      handleChange({
                                        target: {
                                          name: 'financiers',
                                          value: updatedFinanciers
                                        }
                                      });
                                    }}
                                    className="financier-input"
                                    placeholder="Branch Address"
                                  />
                                </td>
                                <td className="financier-action-cell">
                                  {(formData['financiers'] || []).length > 1 && (
                                    <button 
                                      onClick={() => {
                                        const updatedFinanciers = (formData['financiers'] || []).filter((_, i) => i !== index);
                                        handleChange({
                                          target: {
                                            name: 'financiers',
                                            value: updatedFinanciers
                                          }
                                        });
                                      }}
                                      className="financier-remove-btn"
                                      type="button"
                                    >
                                      ✕
                                    </button>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        <div className="financier-add-btn-container">
                          <button
                            type="button"
                            onClick={() => {
                              const currentFinanciers = formData['financiers'] || [{ id: 1, name: '', branchAddress: '' }];
                              const newId = currentFinanciers.length > 0 ? 
                                Math.max(...currentFinanciers.map(f => f.id || 0)) + 1 : 1;
                              handleChange({
                                target: {
                                  name: 'financiers',
                                  value: [...currentFinanciers, { id: newId, name: '', branchAddress: '' }]
                                }
                              });
                            }}
                            className="financier-add-btn"
                          >
                            Add Financier
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                  <div key="co-insurance-details" className="general-section">
                    <h3>Co-Insurance Details</h3>
                    <div className="general-form-group-wrapper">
                      <div className="general-form-group">
                        <div className="coinsurance-checkbox-container">
                          <input
                            type="checkbox"
                            id="hasCoInsurance"
                            checked={formData['hasCoInsurance'] || false}
                            onChange={(e) => {
                              handleChange({
                                target: {
                                  name: 'hasCoInsurance',
                                  value: e.target.checked
                                }
                              });
                            }}
                            className="coinsurance-checkbox"
                          />
                          <label htmlFor="hasCoInsurance">Has Co-Insurance</label>
                        </div>
                      </div>
                    </div>

                    {formData['hasCoInsurance'] && (
                      <div className="coinsurance-table-container">
                        <table className="coinsurance-table">
                          <thead>
                            <tr>
                              <th>Company Name</th>
                              <th>Code</th>
                              <th>Share %</th>
                              <th>Leader/Follower</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(formData['coinsurers'] || [{ id: 1, companyName: '', code: '', sharePercentage: '', leaderFollower: 'Follower' }]).map((insurer, index) => (
                              <tr key={insurer.id || index}>
                                <td>
                                  <input
                                    type="text"
                                    value={insurer.companyName || ''}
                                    onChange={(e) => {
                                      const updatedCoinsurers = [...(formData['coinsurers'] || [{ id: 1, companyName: '', code: '', sharePercentage: '', leaderFollower: 'Follower' }])];
                                      updatedCoinsurers[index] = {
                                        ...updatedCoinsurers[index],
                                        companyName: e.target.value
                                      };
                                      handleChange({
                                        target: {
                                          name: 'coinsurers',
                                          value: updatedCoinsurers
                                        }
                                      });
                                    }}
                                    className="coinsurance-input"
                                    placeholder="Company Name"
                                  />
                                </td>
                                <td>
                                  <input
                                    type="text"
                                    value={insurer.code || ''}
                                    onChange={(e) => {
                                      const updatedCoinsurers = [...(formData['coinsurers'] || [{ id: 1, companyName: '', code: '', sharePercentage: '', leaderFollower: 'Follower' }])];
                                      updatedCoinsurers[index] = {
                                        ...updatedCoinsurers[index],
                                        code: e.target.value
                                      };
                                      handleChange({
                                        target: {
                                          name: 'coinsurers',
                                          value: updatedCoinsurers
                                        }
                                      });
                                    }}
                                    className="coinsurance-input"
                                    placeholder="Code"
                                  />
                                </td>
                                <td>
                                  <input
                                    type="number"
                                    value={insurer.sharePercentage || ''}
                                    onChange={(e) => {
                                      const updatedCoinsurers = [...(formData['coinsurers'] || [{ id: 1, companyName: '', code: '', sharePercentage: '', leaderFollower: 'Follower' }])];
                                      updatedCoinsurers[index] = {
                                        ...updatedCoinsurers[index],
                                        sharePercentage: e.target.value
                                      };
                                      handleChange({
                                        target: {
                                          name: 'coinsurers',
                                          value: updatedCoinsurers
                                        }
                                      });
                                    }}
                                    className="coinsurance-input"
                                    placeholder="Share %"
                                  />
                                </td>
                                <td>
                                  <select
                                    value={insurer.leaderFollower || 'Follower'}
                                    onChange={(e) => {
                                      const updatedCoinsurers = [...(formData['coinsurers'] || [{ id: 1, companyName: '', code: '', sharePercentage: '', leaderFollower: 'Follower' }])];
                                      updatedCoinsurers[index] = {
                                        ...updatedCoinsurers[index],
                                        leaderFollower: e.target.value
                                      };
                                      handleChange({
                                        target: {
                                          name: 'coinsurers',
                                          value: updatedCoinsurers
                                        }
                                      });
                                    }}
                                    className="coinsurance-select"
                                  >
                                    <option value="Leader">Leader</option>
                                    <option value="Follower">Follower</option>
                                  </select>
                                </td>
                                <td className="coinsurance-action-cell">
                                  {(formData['coinsurers'] || []).length > 1 && (
                                    <button 
                                      onClick={() => {
                                        const updatedCoinsurers = (formData['coinsurers'] || []).filter((_, i) => i !== index);
                                        handleChange({
                                          target: {
                                            name: 'coinsurers',
                                            value: updatedCoinsurers
                                          }
                                        });
                                      }}
                                      className="coinsurance-remove-btn"
                                      type="button"
                                    >
                                      ✕
                                    </button>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        <div className="coinsurance-add-btn-container">
                          <button
                            type="button"
                            onClick={() => {
                              const currentCoinsurers = formData['coinsurers'] || [{ id: 1, companyName: '', code: '', sharePercentage: '', leaderFollower: 'Follower' }];
                              const newId = currentCoinsurers.length > 0 ? 
                                Math.max(...currentCoinsurers.map(f => f.id || 0)) + 1 : 1;
                              handleChange({
                                target: {
                                  name: 'coinsurers',
                                  value: [...currentCoinsurers, { id: newId, companyName: '', code: '', sharePercentage: '', leaderFollower: 'Follower' }]
                                }
                              });
                            }}
                            className="coinsurance-add-btn"
                          >
                            Add Co-Insurer
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                  <div key="distribution-channel" className="general-section">
                    <h3>Distribution Channel</h3>
                    <div className="general-form-group-wrapper">
                      <div className="general-form-group">
                        <label htmlFor="distributionChannel">Business Segment</label>
                        <select
                          id="segment"
                          name="Segment"
                          value={formData['Segment'] || ''}
                          onChange={(e) => {
                            const selectedSegment = e.target.value;
                            handleChange(e);
                            setDivisionOptions(parsedSegments[selectedSegment] || []);
                          }}
                          required
                        >
                          <option value="">Select Segment</option>
                          {segmentKeys.map((segment, index) => (
                            <option key={index} value={segment}>
                              {segment}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="general-form-group">
                        <label htmlFor="distributionChannel">Business Division</label>
                        <select
                          id="division"
                          name="Division"
                          value={formData['Division'] || ''}
                          onChange={handleChange}
                          required
                          disabled={!formData['Segment']}
                        >
                          <option value="">Select Division</option>
                          {divisionOptions.map((division, index) => (
                            <option key={index} value={division}>
                              {division}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                  </>
                );
              })()}
            </>
          )}
          <div className="workflow-navigation-buttons">
            <div className="left-button">
              {currentStep > 0 && <button className='general-previous-button' onClick={handlePrevious}>Previous</button>}
            </div>
            <div className="center-button">
              <button className="save-draft-button" onClick={handleSaveDraft}>
                Save as Draft
              </button>
            </div>
            <div className="right-button">
            {currentStep < workflow - 1 ? 
              <button className='general-next-button' onClick={handleNext}>Next</button>:
              <button className='general-next-button' onClick={handleSubmit}>Next</button>
            }
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default GeneralDetails;